<ul class="social social__row clearfix unstyled">
    <li class="social_li">
        <a class="social_link social_link__facebook" data-original-title="facebook" href="#">
            <span class="social_ico"><i class="icon-facebook"></i></span>
        </a>
    </li>
    <li class="social_li">
        <a class="social_link social_link__twitter" data-original-title="twitter" href="#">
            <span class="social_ico"><i class="icon-twitter"></i></span>
        </a>
    </li>
    <li class="social_li">
        <a class="social_link social_link__phone" data-original-title="phone" href="#">
            <span class="social_ico"><i class="icon-phone"></i></span>
        </a>
    </li>
    <li class="social_li">
        <a class="social_link social_link__feed" data-original-title="feed" href="#">
            <span class="social_ico"><i class="icon-rss"></i></span>
        </a>
    </li>
    <li class="social_li">
        <a class="social_link social_link__linkedin" data-original-title="linkedin" href="#">
            <span class="social_ico"><i class="icon-linkedin"></i></span>
        </a>
    </li>
    <li class="social_li">
        <a class="social_link social_link__pinterest" data-original-title="pinterest" href="#">
            <span class="social_ico"><i class="icon-pinterest"></i></span>
        </a>
    </li>
    <li class="social_li">
        <a class="social_link social_link__github" data-original-title="github" href="#">
            <span class="social_ico"><i class="icon-github"></i></span>
        </a>
    </li>
    <li class="social_li">
        <a class="social_link social_link__google+" data-original-title="google+" href="#">
            <span class="social_ico"><i class="icon-google-plus"></i></span>
        </a>
    </li>
</ul>