<div class="headerlogo four columns">
	<div class="logo">
		<a href="{{URL::route('home')}}" title="Touch a Life Foundation">
			<h4>{{ HTML::image('images/logo.jpg', 'Glory Glow Africa') }}</h4>
		</a>
	</div>
</div>
