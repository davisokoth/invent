<!--Carousel Wrapper-->
    <div id="carousel-example-1" class="carousel slide carousel-fade" data-ride="carousel">
        <!--Indicators-->
        <ol class="carousel-indicators">
            <li data-target="#carousel-example-1" data-slide-to="0" class="active"></li>
            <li data-target="#carousel-example-1" data-slide-to="1"></li>
            <li data-target="#carousel-example-1" data-slide-to="2"></li>
            <li data-target="#carousel-example-1" data-slide-to="3"></li>
            <li data-target="#carousel-example-1" data-slide-to="4"></li>
            <li data-target="#carousel-example-1" data-slide-to="5"></li>
            <li data-target="#carousel-example-1" data-slide-to="6"></li>
        </ol>
        <!--/.Indicators-->

        <!--Slides-->
        <div class="carousel-inner" role="listbox">

            <!--First slide-->
            <div class="carousel-item active">
                <!--Caption-->
                <div class="flex-left animated fadeIn">
                    <ul class="carousel-list">
                        <li>
                            <p>"Important truths concerning the heavenly sanctuary and the great work there carried forward for 
				man's redemption were to be taught by the earthly sanctuary and its services." <i>Counsels for the Church, p. 347</i></p>
                        </li>
                    </ul>
                </div>
                <!--Caption-->
            </div>
            <!--/.First slide-->

            <!--Second slide -->
            <div class="carousel-item">
                <!--Caption-->
                <div class="flex-left animated fadeIn">
                    <ul class="carousel-list">
                        <li>
                            <p>"We should be <b>earnest students of prophecy</b>; we should not rest until we become intelligent in regard to the subject
				of the sanctuary." <i>Evangelism, p. 222</i></p>
                        </li>
                    </ul>
                </div>
                <!--Caption-->
            </div>
            <!--/.Second slide -->

            <!--Third slide-->
            <div class="carousel-item">
                <!--Caption-->
                <div class="flex-left animated fadeIn">
                    <ul class="carousel-list">
			<li>
                            <p>"The sanctuary in heaven is <b>the very center of Christ's work</b> in behalf of men... 
				It opens to view the plan of redemption, bringing us down to the very close of time..." <i>The Great Controversy, pp. 488</i></p>
                        </li>
                    </ul>
                </div>
                <!--Caption-->
            </div>
            <!--/.Third slide-->
            
	    <!--Fourth slide-->
            <div class="carousel-item">
                <!--Caption-->
                <div class="flex-left animated fadeIn">
                    <ul class="carousel-list">
                        <li>
                            <p>"The correct understanding of the ministration in the heavenly sanctuary is <b>the foundation of our faith</b>." <i>Evangelism, p. 221</i></p>
                        </li>
                    </ul>
                </div>
                <!--Caption-->
            </div>
            <!--/.Fourth slide-->
            
	    <!--Fifth slide-->
            <div class="carousel-item">
                <!--Caption-->
                <div class="flex-left animated fadeIn">
                    <ul class="carousel-list">
                        <li>
                            <p>"The subject of the sanctuary... opened to view a complete system of truth, connected and harmonious, showing that 
				God's hand had directed the great advent movement." <i>The Great Controversy, p. 423</i></p>
                        </li>
                    </ul>
                </div>
                <!--Caption-->
            </div>
            <!--/.Fifth slide-->
            
	    <!--Sixth slide-->
            <div class="carousel-item">
                <!--Caption-->
                <div class="flex-left animated fadeIn">
                    <ul class="carousel-list">
                        <li>
                            <p>"While Christ is cleansing the sanctuary, the worshipers on earth should carefully review their life, 
				and compare their character with the standard of righteousness." <i>Evangelism, p. 224</i></p>
                        </li>
                    </ul>
                </div>
                <!--Caption-->
            </div>
            <!--/.Fifth slide-->
            
	    <!--Seventh slide-->
            <div class="carousel-item">
                <!--Caption-->
                <div class="flex-left animated fadeIn">
                    <ul class="carousel-list">
                        <li>
                            <p>"God's people are now to have their eyes fixed on the heavenly sanctuary, where the final ministration of 
				our great High Priest in the work of the judgment is going forward,--where He is interceding for His people." <i>Review and Herald, Nov. 27, 1883</i></p>
                        </li>
                    </ul>
                </div>
                <!--Caption-->
            </div>
            <!--/.Fifth slide-->
        </div>
        <!--/.Slides-->

        <!--Controls-->
        <a class="left carousel-control" href="#carousel-example-1" role="button" data-slide="prev">
            <span class="icon-prev" aria-hidden="true"></span>
            <span class="sr-only">Previous</span>
        </a>
        <a class="right carousel-control" href="#carousel-example-1" role="button" data-slide="next">
            <span class="icon-next" aria-hidden="true"></span>
            <span class="sr-only">Next</span>
        </a>
        <!--/.Controls-->
    </div>
    <!--/.Carousel Wrapper-->

