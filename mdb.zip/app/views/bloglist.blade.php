@extends('layouts.main')
@section('head')
    @parent
@stop

@section('body')
<!--breadcrumbs start-->
    <div class="breadcrumbs">
      <div class="container">
        <div class="row">
          <div class="col-lg-4 col-sm-4"><h1>Articles</h1></div>
          <div class="col-lg-8 col-sm-8">
            <ol class="breadcrumb pull-right">
              <li><a href="#">Home</a></li>
              <li><a href="#">Blog</a></li>
            </ol>
          </div>
        </div>
      </div>
    </div>
    <!--breadcrumbs end-->

    <!--container start-->
    <div class="container">
      <div class="row">
        <!--blog start-->
        <div class="col-lg-9">
	  @foreach($blogs as $blog)
          <div class="blog-item">
            <div class="row">
              <div class="col-lg-2 col-sm-2">
                <div class="date-wrap">
                  <span class="date">{{date('d', strtotime($blog->created_at))}}</span>
                  <span class="month">{{date('M', strtotime($blog->created_at))}}</span>
                </div>
              </div>
              <div class="col-lg-10 col-sm-10">
                <div class="blog-img">
                  {{HTML::image('images/blog/'.$blog->blogimage)}}
                </div>
              </div>
            </div>
            <div class="row">
              <div class="col-lg-2 col-sm-2 text-right">
                <div class="author">By <a href="#">{{$blog->user->first_name.' '.$blog->user->last_name}}</a></div>
                <div class="st-view">
                  <ul class="list-unstyled">
                    <li><a href="javascript:;">{{$blog->numberviews}} View</a></li>
                  </ul>
                </div>
              </div>
              <div class="col-lg-10 col-sm-10">
                <h1>
                  <a href="{{URL::route('blogs.get', $blog->id)}}">{{$blog->title}}</a>
                </h1>
                <p>
                  {{$blog->brief}}
                </p>
                <a href="{{URL::route('blogs.get', $blog->id)}}" class="btn btn-primary">
                  Continue Reading
                </a>
              </div>
            </div>
          </div>
	  @endforeach

          <!--
	  <div class="text-center">
            <ul class="pagination">
              <li>
                <a href="#">
                  «
                </a>
              </li>
              <li class="active">
                <a href="#">
                  1
                </a>
              </li>
              <li>
                <a href="#">
                  2
                </a>
              </li>
              <li>
                <a href="#">
                  3
                </a>
              </li>
              <li>
                <a href="#">
                  4
                </a>
              </li>
              <li>
                <a href="#">
                  5
                </a>
              </li>
              <li>
                <a href="#">
                  »
                </a>
              </li>
            </ul>
          </div>
 	  -->

        </div>

        <div class="col-lg-3">
          <div class="blog-side-item">
            <div class="search-row">
              <input type="text" class="form-control" placeholder="Search here">
            </div>
	    
	    <!--
            <div class="category">
              <h3>
                Categories
              </h3>
              <ul class="list-unstyled">
                <li>
                  <a href="javascript:;">
                    <i class="fa fa-angle-right pr-10">
                    </i>
                    Animals
                  </a>
                </li>
                <li>
                  <a href="javascript:;">
                    <i class="fa fa-angle-right pr-10">
                    </i>
                    Landscape
                  </a>
                </li>
                <li>
                  <a href="javascript:;">
                    <i class="fa fa-angle-right pr-10">
                    </i>
                    Portait
                  </a>
                </li>
                <li>
                  <a href="javascript:;">
                    <i class="fa fa-angle-right pr-10">
                    </i>
                    Wild Life
                  </a>
                </li>
                <li>
                  <a href="javascript:;">
                    <i class="fa fa-angle-right pr-10">
                    </i>
                    Video
                  </a>
                </li>
              </ul>
            </div>
	    -->

            <div class="blog-post">
              <h3>
                Latest Blog Post
              </h3>
              <div class="media">
                <a class="pull-left" href="javascript:;">
                  {{HTML::image('img/blog/blog-thumb-1.jpg')}}
                </a>
                <div class="media-body">
                  <h5 class="media-heading">
                    <a href="javascript:;">
                      02 May 2014
                    </a>
                  </h5>
                  <p>
                    Donec id elit non mi porta gravida at eget metus amet int
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>

        <!--blog end-->
      </div>



@stop
