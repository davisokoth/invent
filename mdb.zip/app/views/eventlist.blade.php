@extends('layouts.main')
@section('head')
    @parent
    <title>ALIVE Kenya | Welcome</title>
@stop


@section('body')
<div id="primary" class="sidebar-no">
    <div class="container group">
	<h2>Events</h2>
        <p>&nbsp;</p>
        <div class="row">
		<div class="eight columns">
                	    @foreach($events as $event)
                                    <h4>{{$event->name}}</h4>
		                    <div class="well">
		                            <p>{{$event->description}}</p>
		                            <div class="meta">
		                                &nbsp;&nbsp;Venue: {{$event->venue}}<br />
		                                &nbsp;&nbsp;Date: {{date('D, d M Y', strtotime($event->eventdate))}}<br />
		                                &nbsp;&nbsp;Cost: KES. {{number_format($event->cost, 2)}}<br />
		                                
		                             </div>
		                    </div>
                            @endforeach
                        </div>
                        <div id="sidebar-home-3" class="four columns sidebar group">
                            <div id="testimonial-widget-2" class="widget-first widget testimonial-widget">
                                <h3>Testimonials</h3>
                                <div class="testimonial-text">
                                    <ul class="slides">

                                        <li>
                                            <div>
                                                    <p>
                                                        I have been volunteering with Touch a Life Foundation. We have traversed the country and met many people. 
                                                        It has been a tremendous opportunity to make meaningful and lasting differences in people's lives... I hope to do
                                                        this over and over again.
                                                    </p>
                                                <a href="testimonials-erica.html" class="more-link">[...]</a>
                                                <div class="name-testimonial">
                                                    <a class="name-testimonial" href="testimonials-erica.html">Erica Evans</a>
                                                    <br />
                                                    <a class='url-testimonial' href=""></a>
                                                </div>
                                                <div class="clear"></div>
                                            </div>
                                        </li>

                                        <li>
                                            <div>
                                                    <p>
                                                        At times we plant tress, other times we make nature do something... but we are always touching lives. This isgood for us
                                                        We always need to touch lives..</p>
                                                    <a href="#" class="more-link">[...]</a>
                                                <div class="name-testimonial">
                                                    <a class="name-testimonial" href="#">Ricardo Mori</a>
                                                    <br />
                                                    <a class='url-testimonial' href=""></a>
                                                </div>
                                                <div class="clear"></div>
                                            </div>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                            <script type="text/javascript">
                                jQuery(document).ready(function($){
                                    $('.testimonial-widget ul').css( 'max-height', 'none' );

                                    var animation = $.browser.msie || $.browser.opera ? 'fade' : 'slide';
                                    $('.testimonial-widget').flexslider({
                                        animation: animation,
                                        slideshowSpeed: 8000,
                                        animationSpeed: 300,
                                        selectors: '.slides > li',
                                        directionNav: true,
                                        slideshow: true,

                                        pauseOnAction: false,
                                        controlNav: false,
                                        touch: true
                                    });
                                });
                            </script>

                            <div id="popular-posts-5" class="widget-2 widget-last widget popular-posts">
                                <h3>Coming Events</h3>
                                <div class="recent-post">
                                    <div class="post type-post status-publish format-gallery hentry category-web-design group">

                                        @foreach($events as $event)
                                            <div id="events" class="row">
                                                <div class="date">
                                                    <span class="month">{{date('M', strtotime($event->eventdate))}}</span>
                                                    <span class="day">{{date('d', strtotime($event->eventdate))}}</span>
                                                </div>

                                                <div class="text">
                                                    <h3>
                                                        <a href="{{URL::route('events.get', $event->id)}}" title="{{$event->title}}">
                                                            {{$event->name}}
                                                        </a>
                                                    </h3>
                                                </div>
                                            </div>
                                        @endforeach
                                    </div>
                                </div>
                            </div>
                        </div>
                    <script>
                        jQuery(document).ready(function($){
                            $('.accordion-title').click(function(){
                                if( !$(this).hasClass('active') ) {
                                    $('.accordion-title').removeClass('active').find(':first-child').addClass('plus').text("+").removeClass('minus');
                                    $('.accordion-item').slideUp();

                                    $(this).toggleClass('active')
                                            .find(':first-child').removeClass('plus').addClass('minus').text("-").parent().next().slideToggle();
                                }
                            }).filter(':first').click();
                        });
                    </script>
                </div>
            </div>
            <!-- END CONTENT -->
        </div>
    </div>
</div><!-- END PRIMARY -->
@stop
