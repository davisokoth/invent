@extends('layouts.main')
@section('head')
    @parent
    <title>Mentoring Visions Publishers | Admin</title>
@stop

@section('body')

<div class="container">
    <div class="row">
        <div class="col-md-12">
            @if (Session::has('message'))
                <div class="flash alert">
                    <p>{{ Session::get('message') }}</p>
                </div>
            @endif
            @foreach ($errors->all() as $error)
                <div class="alert">
                    <button class="close" data-dismiss="alert">&times;</button>
                    <strong>Warning!</strong> {{ $error }}
                </div>
            @endforeach
            <h2>New Blog</h2>
                {{ Former::secure_horizontal_open_for_files()
                    ->id('newevent')->action(URL::route('blogs.start'))
                    ->rules(['name' => 'required'])->method('POST');
                }}

                {{ Form::label('title', 'Title')}}
                {{Form::text('title','', array('required'=>'required', 'class'=>'col-md-12'))}}
                <p>&nbsp;</p>
		{{ Form::label('entry', 'Content')}}
                {{ Form::textarea('brief', null, array(
                    'class' => 'col-md-12'
                )) }}
                {{ Form::label('entry', 'Content')}}
                {{ Form::textarea('entry', null, array(
                    'class' => ' col-md-12'
                )) }}
                <p>&nbsp;</p>
		{{ Form::label('banner', 'Select a nice, large (640 X 400 px) image for this entry.') }}
		    {{ Form::file('banner') }}
		<p>&nbsp;</p>
                <div class="offset1 content group">
                    {{Form::submit('Submit', array('class' => 'btn btn-primary', 'id' => 'form-submit'))}}
                    {{Form::reset('Reset Form', array('class' => 'btn btn-error', 'id' => 'form-reset'))}}
                </div>
                {{Former::close()}}
		<p>&nbsp;</p>

        </div>
    </div>
</div><!-- END PRIMARY -->
@stop

