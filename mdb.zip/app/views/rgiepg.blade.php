@extends('layouts.main')
@section('head')
  @parent
  <title>ALIVE Kenya | Login</title>
@stop


@section('body')
<div id="primary" class="sidebar-no">
  <div class="container group">
    <div class="row">
      <!-- START EXTRA CONTENT -->
      <div class="extra-content group span12">
        <div class="section ch-grid">
        <!-- START EXTRA CONTENT -->
          <div class="extra-content group span12">
            @foreach ($errors->all() as $error)
            <div class="alert">
              <button class="close" data-dismiss="alert">&times;</button>
              <strong>Warning!</strong> {{ $error }}
            </div>
            @endforeach

{{ Form::open(array( 'route'	=>	'auth.register' )) }}
<div class="span4 offset4">
<input type="text" id="firstname" name="first_name" placeholder="First name" class="">
<input type="text" id="lastname" name="last_name" placeholder="Last name" class="">
<input type="text" id="email" name="email" placeholder="Email" class="">
<input type="text" id="email_confirm" name="email_confirm" placeholder="Confirm Email" class="">
<input type="password" id="password" name="password" placeholder="Password" class="">
<input type="password" id="password_confirm" name="password_confirm" placeholder="Password" class="">
<input type="hidden" name="_token" value="{{ csrf_token() }}" />
<hr class="lighten">
<input type="submit" class="btn btn-info" value="Register" name="register" id="register"/>
<input type="button" class="btn btn-danger" value="Cancel" name="reset" id="reset"/>
<div id="clear"></div>
<div class="">
<small>
<input type="checkbox" name="tnc" id="tnc" class=""/>
I have read the Terms of Use.<br />
</small>
</div>
</div>
<input type="text" id="uncode" name="uncode" placeholder="uncode" class="invisible">
{{Form::close()}}
</div>
</div>
</div>
</div>
</div>
</div>
@stop