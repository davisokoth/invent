@extends('layouts.main')
@section('head')
    @parent
    <title>ALIVE Kenya | Welcome</title>
@stop


@section('body')
<div id="primary" class="sidebar-right">
    <div class="container group">
        <div class="row">
            <!-- START CONTENT -->
            <div id="content-page" class="span9 content group">
                <div class="page type-page status-publish hentry group">
                    <h2>Admin Panel</h2>
                    <p>
                        <a href="{{URL::route('events.new')}}">New Event</a><br />
                        <a href="{{URL::route('blogs.new')}}">New Blog</a>
                </div>
                <!-- START COMMENTS -->
                <div id="comments"></div>
                <!-- END COMMENTS -->
            </div>

            <div class="border-line"></div>

            <div class="section ch-grid">
                    <!-- START EXTRA CONTENT -->
                    <div class="extra-content group span12">
                        
                        <p>&nbsp;</p>
                        <p>&nbsp;</p>
                    </div>
                </div>
                <!-- END EXTRA CONTENT -->
            </div>

            <!-- END CONTENT -->


        </div>
    </div>
</div><!-- END PRIMARY -->
@stop