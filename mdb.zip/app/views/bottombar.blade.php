<div id="bottom-bar" role="contentinfo">
	<div class="wf-wrap">
		<div class="wf-table wf-mobile-collapsed">
			<div id="branding-bottom" class="wf-td">
				{{ HTML::image('img/logo-circle.png', null, array('height' => '80', 'width' => '81', 'class' => 'preload-me'))}}
				<div class="wf-td">
					<div class="wf-float-left">
						Copyright © 2014 Kings Ministers Melodies. All Rights Reserved.												</div>
					</div>
					<div class="wf-td">
						<div class="mini-nav wf-float-right">
							<ul>
								<li class=" menu-item menu-item-type-post_type menu-item-object-page current-menu-item page_item page-item-7074 current_page_item menu-item-22219 act first"><a href="" data-level="1"><span>Home</span></a></li>
								<li class=" menu-item menu-item-type-post_type menu-item-object-page menu-item-has-children menu-item-22226 has-children"><a href="http://www.kingsministers.org/about-us/" data-level="1"><span>About Us</span></a><ul class="sub-nav">
								<li class=" menu-item menu-item-type-post_type menu-item-object-page menu-item-22264 first"><a href="http://www.kingsministers.org/about-us/our-history/" data-level="2"><span>Our History</span></a></li>
								<li class=" menu-item menu-item-type-post_type menu-item-object-page menu-item-22281"><a href="http://www.kingsministers.org/about-us/our-core-values/" data-level="2"><span>Our Core Values</span></a></li>
								<li class=" menu-item menu-item-type-post_type menu-item-object-page menu-item-22284"><a href="http://www.kingsministers.org/about-us/what-do-seventh-day-adventists-believe/" data-level="2"><span>What do Seventh-day Adventists believe?</span></a></li>
								<li class=" menu-item menu-item-type-post_type menu-item-object-page menu-item-22291"><a href="http://www.kingsministers.org/about-us/gene-m-donaldson/" data-level="2"><span>Dr. Gene M. Donaldson, Sr. Pastor</span></a></li>
								<li class=" menu-item menu-item-type-post_type menu-item-object-page menu-item-22302"><a href="http://www.kingsministers.org/about-us/ramone-w-griffith/" data-level="2"><span>Ramone. W. Griffith, Associate Pastor</span></a></li> </ul></li>
								<li class=" menu-item menu-item-type-post_type menu-item-object-page menu-item-has-children menu-item-23147 has-children"><a href="http://www.kingsministers.org/ministries/" data-level="1"><span>Ministries</span></a><ul class="sub-nav">
								<li class=" menu-item menu-item-type-post_type menu-item-object-page menu-item-23148 first"><a href="http://www.kingsministers.org/ministries/audio-visual-ministry/" data-level="2"><span>Audio/Visual Ministry</span></a></li>
								<li class=" menu-item menu-item-type-post_type menu-item-object-page menu-item-23152"><a href="http://www.kingsministers.org/ministries/deacons/" data-level="2"><span>Deacons</span></a></li>
								<li class=" menu-item menu-item-type-post_type menu-item-object-page menu-item-23266"><a href="http://www.kingsministers.org/ministries/family-life-ministry/" data-level="2"><span>Family Life Ministry</span></a></li>
								<li class=" menu-item menu-item-type-post_type menu-item-object-page menu-item-23265"><a href="http://www.kingsministers.org/ministries/h-e-l-l-o-ministry/" data-level="2"><span>H.E.L.L.O. Ministry (Greeters)</span></a></li>
								<li class=" menu-item menu-item-type-post_type menu-item-object-page menu-item-23276"><a href="http://www.kingsministers.org/ministries/mwam/" data-level="2"><span>Music and Worship Arts Ministries (MWAM)</span></a></li>
								<li class=" menu-item menu-item-type-post_type menu-item-object-page menu-item-23267"><a href="http://www.kingsministers.org/ministries/personal-ministries/" data-level="2"><span>Personal Ministries</span></a></li> </ul></li>
								<li class=" menu-item menu-item-type-post_type menu-item-object-page menu-item-23589"><a href="http://www.kingsministers.org/bulletin/" data-level="1"><span>Announcements</span></a></li>
								<li class=" menu-item menu-item-type-custom menu-item-object-custom menu-item-23138"><a href="http://www.kingsministers.org/calendar" data-level="1"><span>Calendar</span></a></li>
								<li class=" menu-item menu-item-type-custom menu-item-object-custom menu-item-23157"><a href="https://www.adventistgiving.org/?OrgID=ANB4CG" data-level="1" class="external" rel="nofollow" target="_blank"><span>Giving</span></a></li>
								<li class=" menu-item menu-item-type-post_type menu-item-object-page menu-item-22297"><a href="http://www.kingsministers.org/contact/" data-level="1"><span>Contact</span></a></li>
							</ul>
							<div class="menu-select">
								<select class="hasCustomSelect"
									style="-webkit-appearance: menulist-button; width: 0px; position: absolute; opacity: 0; height: 0px; font-size: 12px; visibility: visible;">
									<option value="">———</option>
									<option value="http://www.kingsministers.org/" data-level="1" selected="selected">Home</option>
									<option value="http://www.kingsministers.org/about-us/" data-level="1">About Us</option>
									<option value="http://www.kingsministers.org/ministries/" data-level="1">Ministries</option>
									<option value="http://www.kingsministers.org/bulletin/" data-level="1">Announcements</option>
									<option value="http://www.kingsministers.org/calendar" data-level="1">Calendar</option>
									<option value="https://www.adventistgiving.org/?OrgID=ANB4CG" data-level="1">Giving</option>
									<option value="http://www.kingsministers.org/contact/" data-level="1">Contact</option>
								</select>

								<span class="customSelect" style="display: inline-block;">
									<span class="customSelectInner" style="width: 0px; display: inline-block;">Home</span>
								</span>
								<span class="customSelect1" style="visibility: visible;">
									<span class="customSelectInner">Main</span>
								</span>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div><!-- .wf-wrap -->
</div><!-- #bottom-bar -->