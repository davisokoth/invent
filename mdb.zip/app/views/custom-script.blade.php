{{ HTML::script('js/jquery-1.8.3.min.js')}}
{{ HTML::script('js/bootstrap.min.js')}}
{{ HTML::script('js/hover-dropdown.js')}}
{{ HTML::script('js/jquery.flexslider.js')}}
{{ HTML::script('assets/bxslider/jquery.bxslider.js')}}
{{ HTML::script('js/jquery.parallax-1.1.3.js')}}
{{ HTML::script('js/wow.min.js')}}
{{ HTML::script('assets/owlcarousel/owl.carousel.js')}}
{{ HTML::script('js/jquery.easing.min.js')}}
{{ HTML::script('js/link-hover.js')}}
{{ HTML::script('js/superfish.js')}}
{{ HTML::script('js/parallax-slider/jquery.cslider.js')}}
<script type="text/javascript">
    $(function() {
        $('#da-slider').cslider({
        	autoplay    : true,
          	bgincrement : 100
        });
    });
</script>
<!--common script for all pages-->
{{ HTML::script('js/common-scripts.js')}}
    <script type="text/javascript">
	    jQuery(document).ready(function() {

        	$('.bxslider1').bxSlider({
          		minSlides: 5,
          		maxSlides: 6,
          		slideWidth: 360,
          		slideMargin: 2,
          		moveSlides: 1,
          		responsive: true,
          		nextSelector: '#slider-next',
          		prevSelector: '#slider-prev',
          		nextText: 'Onward →',
          		prevText: '← Go back'
        	});
      	});

    </script>

    <script>
      	$('a.info').tooltip();

      	$(window).load(function() {
        	$('.flexslider').flexslider({
          		animation: "slide",
          		start: function(slider) {
            		$('body').removeClass('loading');
          		}
        	});
      	});

      	$(document).ready(function() {

        	$("#owl-demo").owlCarousel({

          		items : 4
        	});

      	});

      	jQuery(document).ready(function(){
        	jQuery('ul.superfish').superfish();
      	});

      	new WOW().init();

    </script>

    <script>

      wow = new WOW(
        {
          boxClass:     'wow',      // default
          animateClass: 'animated', // default
          offset:       0          // default
        }
      )
        wow.init();


      $(window).load(function() {
        $('.flexslider').flexslider({
          animation: "slide",
          start: function(slider) {
            $('body').removeClass('loading');
          }
        }
                                   );
      }
                    );




      $(window).scroll(function() {
        $('#skillz').each(function(){
          var imagePos = $(this).offset().top;
          var viewportheight = window.innerHeight;

          var topOfWindow = $(window).scrollTop();
          if (imagePos < topOfWindow+viewportheight) {
            $('.skill_bar').fadeIn('slow');
            $('.skill_one').animate({
              width:'60%'}
                                    , 2000);
            $('.skill_two').animate({
              width:'90%'}
                                    , 2000);
            $('.skill_three').animate({
              width:'70%'}
                                      , 1000);
            $('.skill_four').animate({
              width:'55%'}
                                     , 1000);
            $('.skill_bar_progress p').fadeIn('slow',function(){

            }
                                             );
          }
        }
                         );
      }
                      );

    </script>

