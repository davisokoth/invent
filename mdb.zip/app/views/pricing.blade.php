@extends('layouts.main')
@section('head')
    @parent
@stop

@section('body')
<!--breadcrumbs start-->
    <div class="breadcrumbs">
      <div class="container">
        <div class="row">
          <div class="col-lg-4 col-sm-4">
            <h1>
              Pricing Table
            </h1>
          </div>
          <div class="col-lg-8 col-sm-8">
            <ol class="breadcrumb pull-right">
              <li>
                <a href="#">
                  Home
                </a>
              </li>
              <li class="active">
                Pricing
              </li>
            </ol>
          </div>
        </div>
      </div>
    </div>
    <!--breadcrumbs end-->

    <!--container start-->
    <div class="gray-bg price-container">
      <div class="section first">
        <div class="container">

          <div class="page-header">
            <h1 class="text-center">
              <span class="wow flipInX">
                Pricing and Plans
              </span><br />

              <small class="wow flipInX">
                Publishing fees vary depending on the factors such as the amount of work expected and the desired finishing of the book. 
				The price will therefore be discussed with individual client according to special conditions.
              </small>

            </h1>
          </div>

          <div class="row ">
            <div class="price-two-container">
              
              <div class="col-md-4">
                <div class="pricing-table-two wow fadeInUp">
                  <div class="inner">
                    <div class="title">
                      Basic/
                      <span class="price">
                        Kes. 81,200
                      </span>
                    </div>
                    <p class="desc">Perfect for those who have done this before.</p>
                    <ul class="items">
                      <li class="available">
                        <div class="icon-holder">
                          <i class="fa fa-check text-success "></i>
                        </div>
                        <div class="desc">
                          <span class="text-black">Editing</span>

                        </div>
                      </li>
                      <li class="available">
                        <div class="icon-holder">
                          <i class="fa fa-check text-success "></i>
                        </div>
                        <div class="desc">
                          <span class="text-black">Layout</span>
                        </div>
                      </li>

                      <li class="available">
                        <div class="icon-holder">
                          <i class="fa fa-check text-success ">
                          </i>
                        </div>
                        <div class="desc">
                          <span class="text-black">ISBN Help</span>

                        </div>
                      </li>
                      
                      <li class="available">
                        <div class="icon-holder">
                          <i class="fa fa-check text-success ">
                          </i>
                        </div>
                        <div class="desc">
                          <span class="text-black">Cover Design</span>

                        </div>
                      </li>
                      
                      <li>
                        <div class="icon-holder">
                          <i class="fa fa-times text-error ">
                          </i>
                        </div>
                        <div class="desc">
                          <span class="text-black">Ghost Writing</span>
                        </div>
                      </li>
                      <li>
                        <div class="icon-holder">
                          <i class="fa fa-times text-error ">
                          </i>
                        </div>
                        <div class="desc">
                          <span class="text-black">Sales</span>
                        </div>
                      </li>

                    </ul>
                    <div class="price-actions">
                      <a href="javascript:;" class="btn">
                        Subscribe
                      </a>
                    </div>
                  </div>
                </div>
              </div>
              
              <div class="col-md-4">
                <div class="pricing-table-two highlighted wow fadeInUp">
                  <div class="inner">
                    <div class="title">
                      Jumbo/
                      <span class="price">
                        Kes. 174,000
                      </span>
                    </div>
                    <p class="desc">You have an idea but little time to write</p>
                    <ul class="items">
                      <li class="available">
                        <div class="icon-holder">
                          <i class="fa fa-check text-success "></i>
                        </div>
                        <div class="desc">
                          <span class="text-black">Editing</span>

                        </div>
                      </li>
                      <li class="available">
                        <div class="icon-holder">
                          <i class="fa fa-check text-success "></i>
                        </div>
                        <div class="desc">
                          <span class="text-black">Layout</span>
                        </div>
                      </li>

                      <li class="available">
                        <div class="icon-holder">
                          <i class="fa fa-check text-success ">
                          </i>
                        </div>
                        <div class="desc">
                          <span class="text-black">ISBN Help</span>

                        </div>
                      </li>
                      
                      <li class="available">
                        <div class="icon-holder">
                          <i class="fa fa-check text-success ">
                          </i>
                        </div>
                        <div class="desc">
                          <span class="text-black">Cover Design</span>

                        </div>
                      </li>
                      
                      <li class="available">
                        <div class="icon-holder">
                          <i class="fa fa-check text-success ">
                          </i>
                        </div>
                        <div class="desc">
                          <span class="text-black">Ghost Writing</span>
                        </div>
                      </li>
                      <li>
                        <div class="icon-holder">
                          <i class="fa fa-times text-error ">
                          </i>
                        </div>
                        <div class="desc">
                          <span class="text-black">Sales</span>
                        </div>
                      </li>

                    </ul>
                    <div class="price-actions">
                      <a href="javascript:;" class="btn">
                        Subscribe
                      </a>
                    </div>
                  </div>
                </div>
              </div>
              
              
              
              
              <div class="col-md-4">
                <div class="pricing-table-two wow fadeInUp">
                  <div class="inner">
                    <div class="title">
                      Premium/
                      <span class="price">
                        Kes. 250,000
                      </span>
                    </div>
                    <p class="desc">We take you all the way, buddy.</p>
                    <ul class="items">
                      <li class="available">
                        <div class="icon-holder">
                          <i class="fa fa-check text-success "></i>
                        </div>
                        <div class="desc">
                          <span class="text-black">Editing</span>

                        </div>
                      </li>
                      <li class="available">
                        <div class="icon-holder">
                          <i class="fa fa-check text-success "></i>
                        </div>
                        <div class="desc">
                          <span class="text-black">Layout</span>
                        </div>
                      </li>

                      <li class="available">
                        <div class="icon-holder">
                          <i class="fa fa-check text-success ">
                          </i>
                        </div>
                        <div class="desc">
                          <span class="text-black">ISBN Help</span>

                        </div>
                      </li>
                      
                      <li class="available">
                        <div class="icon-holder">
                          <i class="fa fa-check text-success ">
                          </i>
                        </div>
                        <div class="desc">
                          <span class="text-black">Cover Design</span>

                        </div>
                      </li>
                      
                      <li class="available">
                        <div class="icon-holder">
                          <i class="fa fa-check text-success ">
                          </i>
                        </div>
                        <div class="desc">
                          <span class="text-black">Ghost Writing</span>
                        </div>
                      </li>
                      
                      <li class="available">
                        <div class="icon-holder">
                          <i class="fa fa-check text-success ">
                          </i>
                        </div>
                        <div class="desc">
                          <span class="text-black">Sales</span>
                        </div>
                      </li>

                    </ul>
                    <div class="price-actions">
                      <a href="javascript:;" class="btn">
                        Subscribe
                      </a>
                    </div>
                  </div>
                </div>
              </div>
          </div>
        </div>


      </div>
    </div>
    <!--container end-->

@stop
