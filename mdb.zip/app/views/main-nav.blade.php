<div class="navbar navbar-default navbar-static-top container">
    <div class="navbar-header">
        <button class="navbar-toggle" data-target=".navbar-collapse" data-toggle="collapse" type="button">
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
        </button>
        <a class="navbar-brand" href="{{URL::route('home')}}"><!-- M<span>entoring</span> V<span>isions</span> P<span>ublishers</span></a> -->
        	M<span>entoring</span> V<span>isons</span> P<span>ublishers</span>
        </a>
    </div>
    <div class="navbar-collapse collapse">
        <ul class="nav navbar-nav">
            <li class="dropdown">
                <a href="{{URL::route('home')}}">Home</a>
            </li>
            <li class="dropdown">
                <a class="dropdown-toggle" data-close-others="false" data-delay="0" data-hover=
                    "dropdown" data-toggle="dropdown" href="#">About us <i class="fa fa-angle-down"></i>
                </a>
                <ul class="dropdown-menu">
                    <li>
                        <a href="{{URL::route('about')}}">Company Profile</a>
                    </li>
                    <li>
                    <li>
                        <a href="{{URL::route('faq')}}">FAQ</a>
                    </li>
                    <li>
                        <a href="{{URL::route('pricing')}}">Pricing</a>
                    </li>
                    <!--
                    <li>
                        <a href="#">Terms & Condition</a>
                    </li>
                    <li>
                        <a href="#">Privacy policy</a>
                    </li>
                    -->
                </ul>
            </li>
            <li class="dropdown">
                <a class="dropdown-toggle" data-close-others="false" data-delay="0" data-hover=
                   "dropdown" data-toggle="dropdown" href="#">Books <i class="fa fa-angle-down"></i>
                </a>
                <ul class="dropdown-menu">
                    <li>
                        <a href="#">Bible Studies</a>
                    </li>
                    <li>
                    <li>
                        <a href="#">eBooks</a>
                    </li>
                    <li>
                        <a href="#">Inspirational Books</a>
                    </li>
                    <li>
                        <a href="#">Apologetics</a>
                    </li>
                </ul>
            </li>
            <li class="dropdown">
                <a href="{{URL::route('blogs.list')}}">Articles</i></a>
            </li>
            <li>
                <a href="{{URL::route('contact')}}">Contact us</a>
            </li>
            <li><input class="form-control search" placeholder=" Search" type="text"></li>
	    <li><a href="{{URL::route('admin.home')}}">Admin</a></li>
        </ul>
    </div>
</div>
