@extends('layouts.main')
@section('head')
    @parent
    <title>{{$song->name}} | Playing</title>
    <script>
        $(document).ready(function() {
            $('video, audio').acornMediaPlayer({
                theme: 'darkglass',
                volumeSlider: 'vertical'
            });
        });
    </script>
@stop


@section('body')
<div id="primary" class="sidebar-no">
    <div class="container group">
        <div class="row">
            <div class="container row-fluid">
                <div class="audio-container span4">
                    <figure>
                        {{ HTML::image('images/mediaimgs/'.$song->posterimg, 'Simple Track', array('class' => 'audio-poster')) }}
                        <audio controls="controls" id="108" aria-describedby="demo-descript" preload="metadata">
                            <source src="http://localhost/kmm/public/audio/{{$song->storedname}}.mp3" type="audio/mpeg"></source>
                            <source src="http://localhost/kmm/public/audio/{{$song->storedname}}.ogg" type="audio/ogg"></source>
                            You can download our music <a href="#">here</a>.
                        </audio>
                    </figure>
                </div>
                <div class="span7">
                    <h3>{{$song->name}}</h3>
                    <p>Speaker: <a href="#">{{$author->first_name. ' '.$author->last_name}}</a> ||
                        Album: <a href="#">{{$album->title}}</a> ||
                        Event: <a href="#">{{$program->name}}</a><br />
                       {{$author->description}}
                    </p>
                    @if(isset($tags))
                    <p>Tags:
                        @foreach($tags as $tag)
                            <a href="#">{{$tag->name}}</a>,
                        @endforeach
                    </p>
                    @endif

                    @if(isset($othersongs))
                    <h3>Other Sermons in this Series</h3>
                    <p>
                        <ul>
                            @foreach ($othersongs as $other)
                                <li>
                                    <a href="{{URL::route('songs.get', $other->id)}}">{{$other->name}}</a>
                                </li>
                            @endforeach
                        </ul>
                    </p>
                    @endif
                    </p>
                </div>
            </div>
        </div>
    </div>
</div>

@stop