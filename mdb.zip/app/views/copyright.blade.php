<div class="copyright">
	<div class="row">
		<div class="six columns">
			 <a href="http://www.touchalifefoundation.org"><strong>&copy;Glory Glow Africa</strong></a>
			<?php date_default_timezone_set('Africa/Nairobi'); ?>
			{{date('Y')}}
		</div>
		<div class="six columns">
			<span class="small floatright">Powered by <a href="http://www.ipoint.co.ke" title="iPoint Technologies">iPoint Technologies</a> </span>
		</div>
	</div>
</div>
