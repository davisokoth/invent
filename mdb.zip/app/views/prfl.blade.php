@extends('layouts.blank')
@section('head')
    @parent
    {{ HTML::style('css/blue-theme.css') }}
@stop

@section('body')
 	<!-- ================================================================ -->
	    <div class="">
            <div class="content-block">
                <div class="span12">
                    <!-- Tabs -->
    				@if(!isset($profiles))
    					   @foreach ($errors->all() as $error)
                <div class="alert">
                    <button class="close" data-dismiss="alert">&times;</button>
                    <strong>Warning!</strong> {{ $error }}
                </div>
                @endforeach
            		<div class="row show-grid">
            			<div class="col-md-4">
            				<!-- Thumbnails -->
            				<div class="thumbnails">
            					{{ HTML::image('img/pic.jpg') }}
            					<ul class="list-group">
            						<li class="list-group-item"><span class="icon-briefcase"></span>
                                    <a href="#"><span class="badge">10</span>Projects I've Completed</a></li>
            						<li class="list-group-item"><span class="icon-user"></span>
                                    <a href="#"><span class="badge">14</span>My Trusted Connections</a></li>
            						<li class="list-group-item"><span class="icon-briefcase"></span>
                                    <a href="#"><span class="badge">10</span>Projects I've Created</a></li>
                                    <li class="list-group-item"><span class="icon-briefcase"></span>
                                    <a href="#"><span class="badge">10</span>My Wishlist</a></li>
                                    <li class="list-group-item"><span class="icon-envelope"></span>
                                    <a href="#">Send Me a Message</a></li>
            						<li class="list-group-item"><span class="icon-cog"></span>
                                    <a href="#">My Setings</a></li>
            					</ul>
            				</div><!-- /Thumbnails -->
            			</div>
            			<div class="span8 right-block">
            				<div class="info-block">
                            	@if(isset($profile->title))
            					<h3>{{$profile->title}}</h3>
            					<p>{{$profile->description}}</p>
                                <center><i class="icon-bullhorn"></i> {{$profile->phone1}} |
                                <i class="icon-bullhorn"></i> {{$profile->phone2}} |
                                <i class="icon-move"></i> {{$profile->email}} |
                                <i class="icon-resize"></i> {{$profile->location}}</center>
                                <ul class="social-icon">
            						@if($profile->twitter!='')
                                    	<li><a href="{{$profile->twitter}}" class="social twitter">
                                        	<button class="btn-mini">twitter</button></a></li>
                                    @endif
            						@if($profile->gplus!='')
                                        <li><button class="btn-mini">
                                        <a href="{{$profile->gplus}}" class="social google_plus">gplus</a></button></li>
            						@endif
            						@if($profile->facebook!='')
                                        <li><button class="btn-mini">
                                        <a href="{{$profile->facebook}}" class="social facebook">facebook</a></button></li>
            						@endif
            						@if($profile->skype!='')
                                        <li><button class="btn-mini">
                                        <a href="{{$profile->skype}}" class="social skype">skype</a></button></li>
            						@endif


            					</ul>
            				</div>
            				<div class="content-text">
            					<table class="table table-striped table-hover">
            						<thead>
            						  <tr>
            							<th>Company</th><th>Descrition</th><th>Amount</th>
            						  </tr>
            						</thead>
            						<tbody>
            						  <tr>
            							<td>Smart House</td>
            							<td>Office furniture purchase</td>
            							<td>$52560.10</td>
            						  </tr>
            						</tbody>
            					</table>
            					@else
                                <h3>Edit Profile</h3>
                                {{ Form::open(array( 'route' => 'profiles.start' )) }}
                               	<div class="span6">
                    				<div class="">
                    			        <div class="">
                    			            <label class="radio inline">
                    			                <input type="radio" value="Y" name="is_company"/>
                    			                Company Profile:
                    			            </label>
                    			            <label class="radio inline">
                    			                <input type="radio" value="N" name="is_company"/>
                    			                Personal Profile:
                    			            </label>
                    					</div>
                    				</div>
                    				<div class="">
                                   		<input type="text" id="title" name="title" placeholder="Title" class="span5" required="">
                                   	</div>
                    				<div class="">
                                   		<textarea id="description" name="description" class="span5" rows="6"
                    					placeholder="Description" required=""></textarea>
                                   	</div>
                    				<div class="">
                                   		<input type="text" id="phone1" name="phone1" placeholder="Phone No" class="span5" required="">
                                   	</div>
                    				<div class="">
                                   		<input type="text" id="phone2" name="phone2" placeholder="Other Phone No" class="span5">
                                   	</div>
                    				<div class="">
                                   		<input type="text" id="email" name="email" placeholder="Email" class="span5" required="">
                                   	</div>
                    				<div class="">
                                   		<input type="text" id="street" name="street" placeholder="Street" class="span5">
                                   	</div>
                    				<div class="">
                                   		<input type="text" id="postadd" name="postadd" placeholder="Postal Address" class="span5">
                                   	</div>
                    				<div class="">
                                   		<input type="text" id="postcode" name="postcode" placeholder="Postal Code" class="span5">
                                   	</div>
                    				<div class="">
                                   		<input type="text" id="city" name="city" placeholder="Town/City" class="span5" required="">
                                   	</div>
                    				<div class="">
                                   		<input type="text" id="country" name="country" placeholder="Country" class="span5" required="">
                                   	</div>
                                    <div class=""><hr /></div>
                                    <div class="">
                                   		<input type="text" id="twitter" name="twitter" placeholder="Twitter" class="span5">
                                   	</div>
                    				<div class="">
                                   		<input type="text" id="facebook" name="facebook" placeholder="Facebook" class="span5">
                                   	</div>
                    				<div class="">
                                   		<input type="text" id="gplus" name="gplus" placeholder="Google Plus" class="span5">
                                   	</div>
                    				<div class="">
                                   		<input type="text" id="skype" name="skype" placeholder="Skype" class="span5">
                                   	</div>
                    				<div class="col-lg-8">
                    					<input type="submit" class="btn btn-info" value="Create" name="create" id="create"/>
                    					<input type="button" class="btn btn-danger" value="Cancel" name="reset" id="reset"/>
                    					<br />
                    					<small>
                    						<input type="checkbox" name="tnc" id="tnc" class=""/>
                    							I have read the Terms of Use.<br />
                    					</small>
                    				</div>
                    				<div id="clear"></div>

                               	</div>
                    			<input type="text" id="uncode" name="uncode" placeholder="uncode" class="invisible">
                    		    {{Form::close()}}
            					</table>
                                @endif
            				</div>
            			</div>
            		</div>

                </div>
            </div>
        </div>
   @stop