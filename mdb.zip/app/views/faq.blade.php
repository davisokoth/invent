@extends('layouts.main')
@section('head')
    @parent
@stop

@section('body')
<!--breadcrumbs start--><!--breadcrumbs start-->
    <div class="breadcrumbs">
        <div class="container">
            <div class="row">
                <div class="col-lg-4 col-sm-4">
                    <h1>FAQs</h1>
                </div>
                <div class="col-lg-8 col-sm-8">
                    <ol class="breadcrumb pull-right">
                        <li><a href="#">Home</a></li>
                        <li><a href="#">Pages</a></li>
                        <li class="active">FAQ</li>
                    </ol>
                </div>
            </div>
        </div>
    </div>
    <!--breadcrumbs end-->

    <!--container start-->

        <section id="faq">

        <div class="container">



            <div class="row">

                <div class="col-md-10 col-md-offset-1 mar-b-30">

                <div id="heading">
                  <h1 class="wow flipInX">F.A.Q.</h1>
                  <p class="lead wow fadeIn">You have a question? Someone else might have had the exact same one. Let's find out!</p>
                </div>

                    <!--////////// Accordion Toggle //////////-->
                    <div class="panel-group wow fadeInUp" id="accordion" data-wow-duration="2s">

                        <!-- PANEL 1 -->
                        <div class="panel panel-default">
                            <div class="panel-heading panel-heading-faq">
                                <h4 class="panel-title">
                                    <a class="accordion-toggle" data-toggle="collapse" data-parent="#accordion" href="#collapseOne">
                                    What is behind the name ‘Mentoring Visions Publishers?
                                    </a>
                                </h4>
                            </div>

                            <div id="collapseOne" class="panel-collapse collapse">
                                <div class="panel-body panel-faq">
                                    <p>Kenya is made up of vision bearing individuals who would see more of their desired results if their
                                    dreams were mentored. We are talking about a talented author who perhaps hasn’t recognized his full
                                    potential or a person with a story who may not be in a position to put it into writing. VISP takes the
                                    pleasure in identifying such and points them to a ladder leading to their dreams through publishing.</p>
                                </div>
                            </div>
                        </div>

                        <!-- PANEL 3 -->
                        <div class="panel panel-default">
                            <div class="panel-heading panel-heading-faq">
                                <h4 class="panel-title">
                                    <a class="accordion-toggle" data-toggle="collapse" data-parent="#accordion" href="#collapseThree">
                                    Are you a registered company?
                                    </a>
                                </h4>
                            </div>

                            <div id="collapseThree" class="panel-collapse collapse">
                                <div class="panel-body panel-faq">
                                    <p>Yes, we are recognized by the Government of Kenya.</p>
                                </div>
                            </div>
                        </div>

                        <!-- PANEL 4 -->
                        <div class="panel panel-default">
                            <div class="panel-heading panel-heading-faq">
                                <h4 class="panel-title">
                                    <a class="accordion-toggle" data-toggle="collapse" data-parent="#accordion" href="#collapseFour">
                                    Will my book be recognized internationally?
                                    </a>
                                </h4>
                            </div>

                            <div id="collapseFour" class="panel-collapse collapse">
                                <div class="panel-body panel-faq">
                                    <p>Yes, because your book will have a valid ISBN.</p>
                                </div>
                            </div>
                        </div>

                        <div class="panel panel-default">
                            <div class="panel-heading panel-heading-faq">
                                <h4 class="panel-title">
                                    <a class="accordion-toggle" data-toggle="collapse" data-parent="#accordion" href="#collapseFive">
                                    How many copies of my book can I have?
                                    </a>
                                </h4>
                            </div>

                            <div id="collapseFive" class="panel-collapse collapse">
                                <div class="panel-body panel-faq">
                                    <p>It is possible to have at least 500 copies but we advise our authors to start with 1000 copies which is 
                                    more convenient and affordable. You could sell between 1500 and 2500 a year.</p>
                                </div>
                            </div>
                        </div>

                        <div class="panel panel-default">
                            <div class="panel-heading panel-heading-faq">
                                <h4 class="panel-title">
                                    <a class="accordion-toggle" data-toggle="collapse" data-parent="#accordion" href="#collapseSix">
                                    Do you do ghostwriting?
                                    </a>
                                </h4>
                            </div>

                            <div id="collapseSix" class="panel-collapse collapse">
                                <div class="panel-body panel-faq">
                                    <p>Yes, we help you save time by converting your ideas into books as you retain the authorship.</p>
                                </div>
                            </div>
                        </div>

                        <div class="panel panel-default">
                            <div class="panel-heading panel-heading-faq">
                                <h4 class="panel-title">
                                    <a class="accordion-toggle" data-toggle="collapse" data-parent="#accordion" href="#collapseSeven">
                                    Will you assist me in selling my book?
                                    </a>
                                </h4>
                            </div>

                            <div id="collapseSeven" class="panel-collapse collapse">
                                <div class="panel-body panel-faq">
                                    <p>Yes, we will review your book for free in our website. We are also in a position to help display your book, in a number of Bookshops.</p>
                                </div>
                            </div>
                        </div>

                        <div class="panel panel-default">
                            <div class="panel-heading panel-heading-faq">
                                <h4 class="panel-title">
                                    <a class="accordion-toggle" data-toggle="collapse" data-parent="#accordion" href="#collapseEight">
                                    Do you have other ways of promoting my book?
                                    </a>
                                </h4>
                            </div>

                            <div id="collapseEight" class="panel-collapse collapse">
                                <div class="panel-body panel-faq">
                                    <p>If you are willing, you could do a book launch immediately after the first publication. We help organize
                                    for this at a fee. Aside from that, we have a network of speakers who would be delighted to promote your book to their audiences.</p>
                                </div>
                            </div>
                        </div>

                        <div class="panel panel-default">
                            <div class="panel-heading panel-heading-faq">
                                <h4 class="panel-title">
                                    <a class="accordion-toggle" data-toggle="collapse" data-parent="#accordion" href="#collapseNine">
                                    What does the whole publishing process entail?
                                    </a>
                                </h4>
                            </div>

                            <div id="collapseNine" class="panel-collapse collapse">
                                <div class="panel-body panel-faq">
                                    <p>The first step is to review your manuscript and approve it for editing. You can therefore sign a contract
                                    with us to commit yourself to the whole process. The acquisition editor will take care of the editing
                                    process as the designer works on the layout and the cover design. The final stage will be printing.</p>
                                </div>
                            </div>
                        </div>

                        <div class="panel panel-default">
                            <div class="panel-heading panel-heading-faq">
                                <h4 class="panel-title">
                                    <a class="accordion-toggle" data-toggle="collapse" data-parent="#accordion" href="#collapseTen">
                                    How long does the whole process take once I submit my work?
                                    </a>
                                </h4>
                            </div>

                            <div id="collapseTen" class="panel-collapse collapse">
                                <div class="panel-body panel-faq">
                                    <p>The entire process should take four to six months from the time of submission. But if you want your
                                    book done earlier than that, we will be willing to work with you to accomplish that goal at an extra fee.</p>
                                </div>
                            </div>
                        </div>

                        <div class="panel panel-default">
                            <div class="panel-heading panel-heading-faq">
                                <h4 class="panel-title">
                                    <a class="accordion-toggle" data-toggle="collapse" data-parent="#accordion" href="#collapseEleven">
                                    In what form do I submit my manuscript?
                                    </a>
                                </h4>
                            </div>

                            <div id="collapseEleven" class="panel-collapse collapse">
                                <div class="panel-body panel-faq">
                                    <p>Preferably electronic, sent through E-mail or brought to us on a CD. We can also type a hardcopy manuscript at a fee.</p>
                                </div>
                            </div>
                        </div>

                        <div class="panel panel-default">
                            <div class="panel-heading panel-heading-faq">
                                <h4 class="panel-title">
                                    <a class="accordion-toggle" data-toggle="collapse" data-parent="#accordion" href="#collapseTwelve">
                                    What will be my role as an author during the entire process?
                                    </a>
                                </h4>
                            </div>

                            <div id="collapseTwelve" class="panel-collapse collapse">
                                <div class="panel-body panel-faq">
                                    <p>You are expected to approve changes during the editing process and submit any additional material 
                                    needed for improvement of the book. Your assent for the layout and the cover design concepts will be appreciated too.</p>
                                </div>
                            </div>
                        </div>

                        <div class="panel panel-default">
                            <div class="panel-heading panel-heading-faq">
                                <h4 class="panel-title">
                                    <a class="accordion-toggle" data-toggle="collapse" data-parent="#accordion" href="#collapseThirteen">
                                    How sure can I be that my work will be complete?
                                    </a>
                                </h4>
                            </div>

                            <div id="collapseThirteen" class="panel-collapse collapse">
                                <div class="panel-body panel-faq">
                                    <p>You will be able to sign a contract as an assurance that the entire process is planned for and that the 
                                    entitled task will be finished as agreed.</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div><!-- /col-md-10 -->


            </div>
        </div>

    </section>
@stop
