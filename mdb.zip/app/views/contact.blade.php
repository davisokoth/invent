@extends('layouts.main')
@section('head')
    @parent
    {{ HTML::style('css/contact_form.css')}}
@stop

@section('body')
<!--breadcrumbs start-->
<div class="breadcrumbs">
    <div class="container">
        <div class="row">
            <div class="col-lg-4 col-sm-4">
                <h1>
                    Contacts
                </h1>
            </div>
            <div class="col-lg-8 col-sm-8">
                <ol class="breadcrumb pull-right">
                    <li>
                        <a href="#">
                            Home
                        </a>
                    </li>
                    <li class="active">
                        Contacts
                    </li>
                </ol>
            </div>
        </div>
    </div>
</div>
<!--breadcrumbs end-->

<!--container start-->
<div class="container">
    <div class="row">
        <div class="col-lg-5 col-sm-5 address">
            <section class="contact-infos">
                <h4 class="title custom-font text-black">
                    ADDRESS
                </h4>
                <address>
                    Maasai Lodge,
                    <br>
                    Ongata Rongai, Kenya
                </address>
            </section>
            <section class="contact-infos">
                <h4 class="title custom-font text-black">
                    BUSINESS HOURS
                </h4>
                <p>
                    Sunday - Friday 8am to 4pm
                    <br>
                    Saturday - Closed
                    <br>
                </p>
            </section>
            <section class="contact-infos">
                <h4>
                    TELEPHONE
                </h4>
                <p>
                    <i class="icon-phone"></i>
                    +254 728 134955
                </p>
            </section>
        </div>
        <div class="col-lg-7 col-sm-7 address">
            <h4>
                You can also drop us a line here. We will be glad to hear from you
            </h4>
            <div class="contact-form">
                <form role="form">
                    <div class="form-group">
                        <label for="name">
                            Name
                        </label>
                        <input type="text" placeholder="" id="name" class="form-control">
                    </div>
                    <div class="form-group">
                        <label for="email">
                            Email
                        </label>
                        <input type="text" placeholder="" id="email" class="form-control">
                    </div>
                    <div class="form-group">
                        <label for="phone">
                            Phone
                        </label>
                        <input type="text" id="phone" class="form-control">
                    </div>
                    <div class="form-group">
                        <label for="phone">
                            Message
                        </label>
                        <textarea placeholder="" rows="5" class="form-control"></textarea>
                    </div>
                    <button class="btn btn-info" type="submit">
                        Submit
                    </button>
                </form>
            </div>
        </div>
    </div>
</div>
<!--container end-->

<!--google map start-->
<div class="contact-map">
    <div id="map-canvas" style="width: 100%; height: 400px">
    </div>
</div>
    <!--google map end-->
@stop

@section('footer')
    @parent
@stop
