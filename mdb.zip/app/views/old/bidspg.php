<div class="span9">
		<ul class="breadcrumb">
			<li>You are here: </li>
			<li><a href="index.php">Home</a></li>
			<li>\ <a href="<?=$this->config->base_url()?>index.php/job/listall">List all</a></li>
			<li>\ My Bids</li>
		</ul>
		
		<!-- ================================================================= -->
		
		<!--
		<div class="thumbnail"><img src="bootstrap/img/banner.jpg" alt="#"/>
		-->
		
<!-- ======================================================================================================== -->
	
	<?php
		if(!isset($bids)){
	?>
	<div class="thumbnail">
		<div class="caption">
			<h5 class="text-warning">Content not found</h5>
			<p>The requested item was not found. Kindly go back and check the link</p>
		</div>
	</div>
	<?php } else {
		foreach($bids as $bid){		
	?>
	<div class="thumbnail">
		<div class="caption">
			<h5><a href="<?=$this->config->base_url()?>index.php/job/view/<?=$bid->jobid?>">
				<?=$bid->name?>
				</a>		
			</h5>
			<p class="smaller">
			<a href="<?=$this->config->base_url()?>index.php/user/view/<?=$bid->userid?>">
				@<?=$bid->user_name?></a> ||
			Budget: <?=$this->stringformat->f_number($bid->budget)?> ||
			Starts: <?=$this->stringformat->f_date($bid->startdate)?> ||
			Escrow: <?=$this->stringformat->getYesNo($bid->isescrow)?></p>
			<p><?=$bid->jobdetails?></p>
			<p class="bg-brilliant">Value: <?=$this->stringformat->f_number($bid->bidvalue)?> || 
			Duration: <?=$bid->biddays?> days || 
			Bid Date: <?=$this->stringformat->f_date($bid->biddate)?><br />
			<?=$bid->description?></p>
		</div>
	</<div></div>
		<?php }}?>
</div>