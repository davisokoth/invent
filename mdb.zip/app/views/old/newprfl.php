	<!-- ================================================================ -->
	    <div class="row">
            <div class="block-content collapse in">
                <div class="span12">
                    <!-- Tabs -->
		
		<div class="row show-grid">
			<div class="col-md-4">
				<!-- Thumbnails -->
				<div class="thumbnails">
					<img alt="" src="<?=$this->config->base_url()?>assets/img/pic.jpg">
					<ul class="list-group">
						<li class="list-group-item"><span class="icon-briefcase"></span>
                        <a href="#"><span class="badge">10</span>My Projects</a></li>
						<li class="list-group-item"><span class="icon-user"></span>
                        <a href="#"><span class="badge">14</span>My Contacts</a></li>
						<li class="list-group-item"><span class="icon-envelope"></span>
                        <a href="#"><span class="badge">11</span>Send Me a Message</a></li>
						<li class="list-group-item"><span class="icon-cog"></span> 
                        <a href="#">My Setings</a></li>
					</ul>
				</div><!-- /Thumbnails -->		
			</div>
			<div class="span8 right-block">
				<div class="info-block">
					<h3>Edit Profile</h3>
					<form class="form-horizontal" name="userrg" id="userrg" method="POST"
		action="<?=$this->config->base_url()?>index.php/job/create_job" onsubmit="return validateLogin();">
           	<div class="span6">
				<div class="">
			        <div class="">
			            <label class="radio inline">
			                <input type="radio" value="1" name="isoffered"/>
			                I have:
			            </label>
			            <label class="radio inline">
			                <input type="radio" value="2" name="isoffered"/>
			                I am looking for:
			            </label>
					</div>
					<div class="">
						<label class="radio inline">
			                <input type="radio" value="1" name="isjob"/>
			                A product
			            </label>
			            <label class="radio inline">
			                <input type="radio" value="2" name="isjob"/>
			                A service
			            </label>
			        </div>
				</div>
				<div class="">
               		<input type="text" id="name" name="name" placeholder="Title" class="span5">
               	</div>
				
               	<div class="input-prepend">
               		<span class="add-on">KES:</span>
					<input type="text" id="budget" name="budget" placeholder="budget" class="span5">
               	</div>
				<div class="">
               		<textarea id="description" name="description" class="span5" rows="6" 
					placeholder="Details"></textarea>
               	</div>
				<div class="">
					<input type="checkbox" name="isescrow" id="isescrow" class=""/>
							I'd like to have escrow services.<br />
				</div>
				<div class="">
				    <input type="text" data-role="tagsinput" name="tags" id="tags" 
					placeholder="tags (comma seperated)" class="span5">
					<input type="hidden" name="tagid" id="tagid"/> 	    
				</div>
				<div class="col-lg-8">
					<input type="submit" class="btn btn-info" value="Create" name="create" id="create"/>
					<input type="button" class="btn btn-danger" value="Cancel" name="reset" id="reset"/>
					<br />
					<small>
						<input type="checkbox" name="tnc" id="tnc" class=""/>
							I have read the Terms of Use.<br />
					</small>
				</div>
				<div id="clear"></div>
				
           	</div>
			<input type="text" id="uncode" name="uncode" placeholder="uncode" class="invisible">
		</form>
					</table>
				</div>				
			</div>
		</div>
            
                </div>
            </div>