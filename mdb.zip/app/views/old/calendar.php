<?php
	include('head.php');
?>
<body data-offset="40">
<div class="container">

<?php include('header.php');?>

<!-- ========================================================================================================== -->

<?php include('stdnav.php')?>

<!-- ========================================================================================================== -->
<div class="row">
	<div class="span3">
		<ul class="nav nav-tabs nav-stacked">
			<li><a href="webdevelopment.html"><i class="icon-chevron-right"></i> Jobs Search</a></li>
			<li><a href="webdevelopment.html"><i class="icon-chevron-right"></i> My Pending Tasks</a></li>
			<li><a href="webdevelopment.html"><i class="icon-chevron-right"></i> Calendar</a></li>
			<li><a href="softwaredevelopment.html"><i class="icon-chevron-right"></i> Marketplace</a></li>
			<li><a href="softwaredevelopment.html"><i class="icon-chevron-right"></i> Discuss</a></li>
			<li><a href="softwaredevelopment.html"><i class="icon-chevron-right"></i> Learning Centre</a></li>
		</ul>
		<div class="accordion" id="accordion2">
			<div class="accordion-group">
			  <div class="accordion-heading">
				<a class="accordion-toggle" data-toggle="collapse" data-parent="#accordion2" href="#collapseOne">
				  Step 1:Getting Started
				</a>
			  </div>
			  <div id="collapseOne" class="accordion-body collapse" style="height: 0px;">
				<div class="accordion-inner">
				  Some description here
				</div>
			  </div>
			</div>
			<div class="accordion-group">
			  <div class="accordion-heading">
				<a class="accordion-toggle" data-toggle="collapse" data-parent="#accordion2" href="#collapseTwo">
				  Step 2: Registration
				</a>
			  </div>
			  <div id="collapseTwo" class="accordion-body collapse" style="height: 0px;">
				<div class="accordion-inner">
				  Some description here
				</div>
			  </div>
			</div>
			<div class="accordion-group">
					  <div class="accordion-heading">
						<a class="accordion-toggle collapsed" data-toggle="collapse" data-parent="#accordion2" href="#collapseThree">
						  Step 3:Upload your DESIGN
						</a>
					  </div>
					  <div id="collapseThree" class="accordion-body collapse" style="height: 0px;">
						<div class="accordion-inner">
						  Some more description here
						</div>
					  </div>
					</div>
		 </div>
	</div>
	
		<!-- ================================================================ -->
		
	<div class="span9">
		<ul class="breadcrumb">
			<li>You are here: </li>
			<li><a href="index.php">Home</a>
		</ul>
		
		<!-- ================================================================= -->
		
		<!--
		<div class="thumbnail"><img src="bootstrap/img/banner.jpg" alt="#"/>
		-->
		
<!-- ======================================================================================================== -->
	<div id="calendar" class="col-lg-9"></div>
	
	</div>
</div>
<!-- Footer
      ================================================== -->
	  <?php include('footer.php');?>
	  <script src="assets/lib/fullcalendar-1.6.2/fullcalendar/fullcalendar.min.js"></script>
    <script src="assets/js/main.min.js"></script>
    <script>
      $(function() {
        metisCalendar();
      });
    </script>
	</style>
  </body>
</html>