<div class="span9">
		<ul class="breadcrumb">
			<li>You are here: </li>
			<li><a href="index.php">Home</a></li>
			<li>\ <a href="<?=$this->config->base_url()?>index.php/job/listall">List all</a></li>
			<li>\ <?=$job->name?></li>
		</ul>
		
		<!-- ================================================================= -->
		
		<!--
		<div class="thumbnail"><img src="bootstrap/img/banner.jpg" alt="#"/>
		-->
		
<!-- ======================================================================================================== -->
	<div class="thumbnail">
		<div class="caption">
			<?php
				if(!isset($job)){
			?>
			<h5 class="text-warning">Content not found</h5>
			<p>The requested item was not found. Kindly go back and check the link</p>
			<?php } else {?>
			<h5>
				<a href="<?=$this->config->base_url()?>index.php/welcome/profile">
					@<?=$job->user_name?>
				</a>:: <?=$job->name?></h5>
			<p class="smaller">
				Posted: <?=$this->stringformat->f_date($job->created_on)?> | 
				Budget: KES. <?=$this->stringformat->f_number($job->budget)?> |
				No of bids: <?=$this->stringformat->f_integer($job->nobids)?> |
				<?php
					if($job->status==5){
				?>
				<span class="">Status: <?=$this->stringformat->getStatus($job->status)?></span>
				<?php }else{?>
					Status: <?=$this->stringformat->getStatus($job->status)?>
				<?php }?>
			</p>
			<p><?=$job->description?></p>
			<p class="smaller">
				<?php
					if($tags){
						
						foreach($tags as $tagrow){?>
						<a href="#"><?=$tagrow->name?></a>, 
				<?php }}
				?>
			</p>
			<p>
			<!--
			<i class="icon-comment"></i> <a href="#">Discuss</a> |  
			<i class="icon-briefcase"></i> <a href="<?=$this->config->base_url()?>index.php/job/newbid/
			<?=$job->id?>">Bid</a> |
			<i class="icon-warning-sign"></i> <a href="#">Report</a> |
			<i class="icon-envelope"></i> <a href="#">Send PM</a>-->
			<?php
				if(config_item('auth_user_id')!=$job->userid){
					if(isset($mybid)){
			?><a class="btn btn-primary" 
			href="<?=$this->config->base_url()?>index.php/bid/newbid/<?=$job->id?>">
				&nbsp;&nbsp;&nbsp;<i class="icon-briefcase"></i> Bid&nbsp;&nbsp;&nbsp;</a>
			<?php } else {?><a class="btn btn-primary" 
			href="<?=$this->config->base_url()?>index.php/job/newbid/<?=$job->id?>">
				&nbsp;&nbsp;&nbsp;<i class="icon-briefcase"></i> Bid&nbsp;&nbsp;&nbsp;</a>
			<?php }?>
			<a class="btn btn-danger" 
			href="<?=$this->config->base_url()?>index.php/job/report/<?=$job->id?>">
				<i class="icon-warning-sign"></i> Report</a>
			<a class="btn btn-primary" 
			href="<?=$this->config->base_url()?>index.php/job/sendmsg/<?=$job->id?>">
				<i class="icon-envelope"></i>Send PM</a>
			</p>
            <?php
				}}?>
			<table id="bids" class="table table-bordered table-striped">
				<?php
					if($comments){
						foreach($comments as $bidrow){?>
				<tr>
					<td>
						<div class="smaller"><a href="#"><?=$bidrow->user_name?></a> | 
						<?=$this->stringformat->f_date($bidrow->created_on)?></div>
					<br /><?=$bidrow->description?></td>
				</tr>
				<?php }
					}?>
			</table>
		</div>
	</div>
</div>