<div class="span9">
		<ul class="breadcrumb">
			<li>You are here: </li>
			<li><a href="index.php">Home</a></li>
			<li>\ <a href="<?=$this->config->base_url()?>index.php/job/listall">List all</a></li>
			<li>\ <a href="<?=$this->config->base_url()?>index.php/job/view/<?=$job->id?>"><?=$job->name?></a></li>
			<li>\ Report</li>
		</ul>
		
		<!-- ================================================================= -->
		
		<!--
		<div class="thumbnail"><img src="bootstrap/img/banner.jpg" alt="#"/>
		-->
		
<!-- ======================================================================================================== -->
	<div class="thumbnail">
		<div class="caption">
			<?php
				if(!isset($job)){
			?>
			<h5 class="text-warning">Content not found</h5>
			<p>The requested item was not found. Kindly go back and check the link</p>
			<?php } else {?>
			<h5><?=$job->name?></h5>
			<p><?=$job->description?></p>
			<form class="form-horizontal" name="report" id="report" method="POST"
			action="<?=$this->config->base_url()?>index.php/job/reportjob" onsubmit="return validateLogin();">
               	<div class="span6">
					<div class="">
                   		<input type="hidden" id="jobid" name="jobid" value="<?=$job->id?>">
                   	</div>
                   	<div class="">
						<select name="biddays" class="span5" id="biddays">
							<option value="1">Inappropriate Request/ Offer</option>
							<option value="2">Suspected Fraud</option>
							<option value="3">Other</option>
						</select>
					</div>
					<div class="">
                   		<textarea id="description" name="description" class="span5" rows="6" 
						placeholder="Details"></textarea>
                   	</div>
					<div class="form-actions">
						<input type="submit" class="btn btn-info" value="Report" name="create" id="create"/>
						<input type="button" class="btn btn-danger" value="Cancel" name="reset" id="reset"/>
						<br /><small>
							<input type="checkbox" name="tnc" id="tnc" class=""/>
								I have read the Terms of Use.<br />
						</small>
					</div>
					
               	</div>
				<input type="text" id="uncode" name="uncode" placeholder="uncode" class="invisible">
			</form>
			<?php }?>
		</div>
	</div>
</div>