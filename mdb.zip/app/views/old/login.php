<!doctype html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Laravel PHP Framework</title>
	<style>
		@import url(//fonts.googleapis.com/css?family=Lato:700);

		body {
			margin:0;
			font-family:'Lato', sans-serif;
			text-align:center;
			color: #999;
		}

		.welcome {
			width: 300px;
			height: 200px;
			position: absolute;
			left: 50%;
			top: 50%;
			margin-left: -150px;
			margin-top: -100px;
		}

		a, a:visited {
			text-decoration:none;
		}

		h1 {
			font-size: 32px;
			margin: 16px 0 0 0;
		}
	</style>
</head>
<body>
	<div class="welcome">
		<div class="">
 	<div class="col-lg-6">
    	<div class="blue-bg">
        	<header>
            	<h5><div class="icons">
                <i class="icon-user"></i>
				Login</div></h5>
			</<header>
		</div>
		<div id="clear"></div>
		<div id="" class="well">
           	<h1><?=$squirrel?></h1>
			<form class="form-horizontal" name="userlg" id="userlg" method="POST"
			action="user/login" onsubmit="return validateLogin();">
			
               	<div class="span4 offset4">
                   	<label for="username" class="">Username: </label>
                   	<div class="">
                   		<input type="text" id="login_string" name="login_string" placeholder="Username" class="" 
						autocomplete="off">
                   	</div>
					<label for="password" class="">Password: </label>
                   	<div class="col-lg-8">
                   		<input type="password" name="login_pass" id="login_pass" placeholder="Password" class="" 
						autocomplete="off" maxlength="12">
                   	</div>
					
					<hr class="lighten">
					<div class="col-lg-8">
						<input type="submit" class="btn btn-info" value="Login" name="login" id="login"/>
						<input type="button" class="btn btn-danger" value="Cancel" name="reset" id="reset"/>
					</div>
					<div id="clear"></div>
					<div class="">
						<small><input type="checkbox" name="rem_me" id="rem_me" class=""/> Remember me.<br />
						<a href="static_pages/recover">Forgot Password?</a> | 
						<a href="static_pages/register">Register</a></small>
					</div>
               	</div>
			</form>
		</div>
	</div>
</div>
	</div>
</body>
</html>
