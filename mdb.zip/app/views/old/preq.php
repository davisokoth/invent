<?php if( ! defined('BASEPATH') ) exit('No direct script access allowed');
/**
 * Community Auth - Template Content View
 *
 * Community Auth is an open source authentication application for CodeIgniter 2.1.3
 *
 * @package     Community Auth
 * @author      Robert B Gottier
 * @copyright   Copyright (c) 2011 - 2012, Robert B Gottier. (http://brianswebdesign.com/)
 * @license     BSD - http://http://www.opensource.org/licenses/BSD-3-Clause
 * @link        http://community-auth.com
 */
?><!DOCTYPE html>
<html lang="en">
<head>
<meta http-equiv="content-type" content="text/html; charset=UTF-8" />
<?php
	$this->load->view('head');
?>
</head>
<body data-offset="40">
<div class="container">

<?php $this->load->view('header');?>

<!-- ========================================================================================================== -->

<?php $this->load->view('stdnav');?>

<!-- ========================================================================================================== -->
<div class="row">
	<div class="span3">
		<?php $this->load->view('leftnav');?>
		<div class="accordion" id="accordion2">
			<div class="accordion-group">
			  <div class="accordion-heading">
				<a class="accordion-toggle" data-toggle="collapse" data-parent="#accordion2" href="#collapseOne">
				  Step 1:Getting Started
				</a>
			  </div>
			  <div id="collapseOne" class="accordion-body collapse" style="height: 0px;">
				<div class="accordion-inner">
				  Some description here
				</div>
			  </div>
			</div>
			<div class="accordion-group">
			  <div class="accordion-heading">
				<a class="accordion-toggle" data-toggle="collapse" data-parent="#accordion2" href="#collapseTwo">
				  Step 2: Registration
				</a>
			  </div>
			  <div id="collapseTwo" class="accordion-body collapse" style="height: 0px;">
				<div class="accordion-inner">
				  Some description here
				</div>
			  </div>
			</div>
			<div class="accordion-group">
				<div class="accordion-heading">
					<a class="accordion-toggle collapsed" data-toggle="collapse" data-parent="#accordion2" href="#collapseThree">
						Step 3:Upload your DESIGN
					</a>
				</div>
				<div id="collapseThree" class="accordion-body collapse" style="height: 0px;">
					<div class="accordion-inner">
						<?=$this->session->userdata('user_id').'- '.$this->session->userdata('username')?>
					</div>
				</div>
			</div>
		 </div>
	</div>
	
		<!-- ================================================================ -->
		
	<div class="span9">
		<ul class="breadcrumb">
			<li>You are here: </li>
			<li><a href="index.php">Home</a></li>
			<li>:: <?$criteria?></li>
		</ul>
		
		<!-- ================================================================= -->
		
		<!--
		<div class="thumbnail"><img src="bootstrap/img/banner.jpg" alt="#"/>
		-->
		
<!-- ======================================================================================================== -->
	<?php
		if(isset($job)){
			foreach($job as $row){
	?>
	<div class="thumbnail">
		<div class="caption">
			<span class="pull-right">
				<a href="#" data-placement="right" data-original-title="close">
					<i class="icon-remove"></i>
				</a>
			</span>
			<h5><a href="<?=$this->config->base_url()?>index.php/job/view/<?=$row->id?>"><?=$row->name?></a></h5>
			<p class="smaller">
				Posted: <?=f_date($row->created_on)?> | 
				Budget: KES. <?=f_number($row->budget)?>
			</p>
			<p><?=$row->description?>
			</p>
		</div>
	</div>
	<?php } 
	}
	?>
	</div>
</div>
<!-- Footer
      ================================================== -->
	  <?php $this->load->view('footer');?>
	</style>
  </body>
</html>