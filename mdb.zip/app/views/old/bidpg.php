<div class="span9">
		<ul class="breadcrumb">
			<li>You are here: </li>
			<li><a href="index.php">Home</a></li>
			<li>\ <a href="<?=$this->config->base_url()?>index.php/job/listall">List all</a></li>
			<li>\ <a href="<?=$this->config->base_url()?>index.php/job/view/<?=$bid->jobid?>"><?=$bid->name?></a></li>
		</ul>
		
		<!-- ================================================================= -->
		
		<!--
		<div class="thumbnail"><img src="bootstrap/img/banner.jpg" alt="#"/>
		-->
		
<!-- ======================================================================================================== -->
	<div class="thumbnail">
		<div class="caption">
			<?php
				if(!isset($bid)){
			?>
			<h5 class="text-warning">Content not found</h5>
			<p>The requested item was not found. Kindly go back and check the link</p>
			<?php } else {?>
			<h5><?=$bid->name?></h5>
			<p><?=$bid->description?></p>
			<p>
			<!--
			<i class="icon-comment"></i> <a href="#">Discuss</a> |  
			<i class="icon-briefcase"></i> <a href="<?=$this->config->base_url()?>index.php/job/newbid/
			<?=$job->id?>">Bid</a> |
			<i class="icon-warning-sign"></i> <a href="#">Report</a> |
			<i class="icon-envelope"></i> <a href="#">Send PM</a>-->
			<?php
				if(isset($mybid)){
			?><a class="btn btn-primary" 
			href="<?=$this->config->base_url()?>index.php/bid/newbid/<?=$job->id?>">
				&nbsp;&nbsp;&nbsp;<i class="icon-briefcase"></i> Bid&nbsp;&nbsp;&nbsp;</a>
			<?php } else {?><a class="btn btn-primary" 
			href="<?=$this->config->base_url()?>index.php/job/newbid/<?=$job->id?>">
				&nbsp;&nbsp;&nbsp;<i class="icon-briefcase"></i> Bid&nbsp;&nbsp;&nbsp;</a>
			<?php }?>
			<a class="btn btn-danger" 
			href="<?=$this->config->base_url()?>index.php/job/report/<?=$job->id?>">
				<i class="icon-warning-sign"></i> Report</a>
			<a class="btn btn-primary" 
			href="<?=$this->config->base_url()?>index.php/job/sendmsg/<?=$job->id?>">
				<i class="icon-envelope"></i>Send PM</a>
			</p>
			<table id="bids" class="table table-bordered table-striped">
				<?php
					if($comments){
						foreach($comments as $bidrow){?>
				<tr>
					<td>
						<div class="smaller"><a href="#"><?=$bidrow->user_name?></a> | 
						<?=$this->stringformat->f_date($bidrow->created_on)?></div>
					<br /><?=$bidrow->description?></td>
				</tr>
				<?php }
					}?>
			</table>
			<?php }?>
		</div>
	</div>
</div>