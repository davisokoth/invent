	<!-- ================================================================ -->
		
	<div class="span9">
		<ul class="breadcrumb">
			<li>You are here: </li>
			<li><a href="<?=$this->config->base_url()?>">Home</a></li>
		</ul>
		
		<!-- ================================================================= -->
		
		<!--
		<div class="thumbnail"><img src="bootstrap/img/banner.jpg" alt="#"/>
		-->
		
        <!-- ================================================================= -->
	<div class="row">
	<div class="block-content collapse in">
    <div class="span12">
 		<div class="">
           	<form class="form-horizontal" name="userrg" id="userrg" method="POST"
			action="<?=$this->config->base_url()?>index.php/job/bid" onsubmit="return validateLogin();">
               	<div class="span6">
					<div class="">
                   		<input type="hidden" id="jobid" name="jobid" value="<?=$job->id?>">
                   	</div>
                   	<div class="input-prepend">
                   		<span class="add-on">KES:</span>
						<input type="text" id="bidvalue" name="bidvalue" placeholder="bid value" class="span5">
                   	</div>
					<div class="">
						<select name="biddays" class="span5" id="biddays">
							<option value="0">Same Day</option>
							<option value="7">Within 7 Days</option>
							<option value="14">Within 2 weeks</option>
							<option value="30">Within this Month</option>
							<option value="90">Within 3 Months</option>
							<option value="100">More than 3 Months</option>
						</select>
					</div>
					<div class="">
                   		<textarea id="description" name="description" class="span5" rows="6" 
						placeholder="Details"></textarea>
                   	</div>
					<div class="form-actions">
						<input type="submit" class="btn btn-info" value="Bid" name="create" id="create"/>
						<input type="button" class="btn btn-danger" value="Cancel" name="reset" id="reset"/>
						<br /><small>
							<input type="checkbox" name="tnc" id="tnc" class=""/>
								I have read the Terms of Use.<br />
						</small>
					</div>
					
               	</div>
				<input type="text" id="uncode" name="uncode" placeholder="uncode" class="invisible">
			</form>
		</div>
	</div></div></div></div>