<?php
	$this->load->view('head');
?>
<body data-offset="40">
<div class="container">

<?php $this->load->view('header');?>

<!-- ========================================================================================================== -->

<?php $this->load->view('stdnav');?>

<!-- ========================================================================================================== -->
<div class="row">
	<div class="span3">
		<?php $this->load->view('leftnav');?>
		<div class="accordion" id="accordion2">
			<div class="accordion-group">
			  <div class="accordion-heading">
				<a class="accordion-toggle" data-toggle="collapse" data-parent="#accordion2" href="#collapseOne">
				  Step 1:Getting Started
				</a>
			  </div>
			  <div id="collapseOne" class="accordion-body collapse" style="height: 0px;">
				<div class="accordion-inner">
				  Some description here
				</div>
			  </div>
			</div>
			<div class="accordion-group">
			  <div class="accordion-heading">
				<a class="accordion-toggle" data-toggle="collapse" data-parent="#accordion2" href="#collapseTwo">
				  Step 2: Registration
				</a>
			  </div>
			  <div id="collapseTwo" class="accordion-body collapse" style="height: 0px;">
				<div class="accordion-inner">
				  Some description here
				</div>
			  </div>
			</div>
			<div class="accordion-group">
				<div class="accordion-heading">
					<a class="accordion-toggle collapsed" data-toggle="collapse" data-parent="#accordion2" href="#collapseThree">
						Step 3:Upload your DESIGN
					</a>
				</div>
				<div id="collapseThree" class="accordion-body collapse" style="height: 0px;">
					<div class="accordion-inner">
						<?=$this->session->userdata('logged_in').'- '.$this->session->userdata('username')?>
					</div>
				</div>
			</div>
		 </div>
	</div>
	
		<!-- ================================================================ -->
		
	<div class="span9">
		<ul class="breadcrumb">
			<li>You are here: </li>
			<li><a href="index.php">Home</a></li>
			<li>: Profile</li>
		</ul>
		
		<!-- ================================================================= -->
		
		<!--
		<div class="thumbnail"><img src="bootstrap/img/banner.jpg" alt="#"/>
		-->
		
<!-- ======================================================================================================== -->
	<div class="span9">
	<ul class="breadcrumb">
			<li><a href="index.html">Home</a> <span class="divider">/</span></li>
			<li class="active">Portfolio</li>
		</ul>
		
		
		<ul class="nav nav-pills pull-right">
			<li class=""><a href="#comingsoon" data-toggle="tab">COMING SOON</a></li>
			<li class=""><a href="#popular" data-toggle="tab">POPULAR</a></li>
			<li class=""><a href="#new" data-toggle="tab">NEW</a></li>
			<li class="active"><a href="#all" data-toggle="tab">ALL</a></li>
		</ul>
		<h2>Portfolio</h2>
		
		<hr class="soften"/>
		<div class="tabbable tabs">
		  <div class="tab-content label-primary">
		<div class="tab-pane active" id="all">
		<ul class="thumbnails">
				<li class="span3">
					<div class="thumbnail">
						<h4>My web solutions</h4>
						<a href="#"><img src="bootstrap/img/portfolio/1.jpg" alt="bootstrap business templates"></a>
						<p>Our aim is simple - to provide affordable web design and development services for different devices. </p>
						<div class="btn-toolbar">
						  <div class="btn-group toolTipgroup">
							<a class="btn" href="#" data-placement="right" data-original-title="send email"><i class="icon-envelope"></i></a>
							<a class="btn" href="#" data-placement="top" data-original-title="do you like?"><i class="icon-thumbs-up"></i></a>
							<a class="btn" href="#" data-placement="top" data-original-title="dont like?"><i class="icon-thumbs-down"></i></a>
							<a class="btn" href="#" data-placement="top" data-original-title="share"><i class="icon-link"></i></a>
							<a class="btn" href="#" data-placement="left" data-original-title="browse"><i class="icon-globe"></i></a>
						  </div>
						</div>
					</div>
					</li>
					<li class="span3">
						<div class="thumbnail">
							<div class="blockDtl">
							<h4>My web solutions</h4>
							<a href="#"><img src="bootstrap/img/portfolio/9.jpg" alt="bootstrap business templates"></a>
							<p>Our aim is simple - to provide affordable web design and development services for different devices. </p>
							<div class="btn-toolbar">
							   <div class="btn-group toolTipgroup">
								<a class="btn" href="#" data-placement="right" data-original-title="send email"><i class="icon-envelope"></i></a>
								<a class="btn" href="#" data-placement="top" data-original-title="do you like?"><i class="icon-thumbs-up"></i></a>
								<a class="btn" href="#" data-placement="top" data-original-title="dont like?"><i class="icon-thumbs-down"></i></a>
								<a class="btn" href="#" data-placement="top" data-original-title="share"><i class="icon-link"></i></a>
								<a class="btn" href="#" data-placement="left" data-original-title="browse"><i class="icon-globe"></i></a>
							  </div>
							</div>
							</div>
						</div>
					</li>
					<li class="span3">
						<div class="thumbnail">
							<div class="blockDtl">
							<h4>My web solutions</h4>
							<a href="#"><img src="bootstrap/img/portfolio/3.jpg" alt="bootstrap business templates"></a>
							<p>Our aim is simple - to provide affordable web design and development services for different devices. </p>
							<div class="btn-toolbar">
							   <div class="btn-group toolTipgroup">
								<a class="btn" href="#" data-placement="right" data-original-title="send email"><i class="icon-envelope"></i></a>
								<a class="btn" href="#" data-placement="top" data-original-title="do you like?"><i class="icon-thumbs-up"></i></a>
								<a class="btn" href="#" data-placement="top" data-original-title="dont like?"><i class="icon-thumbs-down"></i></a>
								<a class="btn" href="#" data-placement="top" data-original-title="share"><i class="icon-link"></i></a>
								<a class="btn" href="#" data-placement="left" data-original-title="browse"><i class="icon-globe"></i></a>
							  </div>
							</div>
							</div>
						</div>
					</li>
					<li class="span3">
						<div class="thumbnail">
							<div class="blockDtl">
							<h4>My web solutions</h4>
							<a href="comingsoon.html"><img src="bootstrap/img/portfolio/4.jpg" alt="bootstrap business templates"></a>
							<p>Our aim is simple - to provide affordable web design and development services for different devices. </p>
							<div class="btn-toolbar">
							   <div class="btn-group toolTipgroup">
								<a class="btn" href="#" data-placement="right" data-original-title="send email"><i class="icon-envelope"></i></a>
								<a class="btn" href="#" data-placement="top" data-original-title="do you like?"><i class="icon-thumbs-up"></i></a>
								<a class="btn" href="#" data-placement="top" data-original-title="dont like?"><i class="icon-thumbs-down"></i></a>
								<a class="btn" href="#" data-placement="top" data-original-title="share"><i class="icon-link"></i></a>
								<a href="comingsoon.html" class="btn" data-placement="left" data-original-title="browse"><i class="icon-globe"></i></a>
							  </div>
							</div>
							</div>
						</div>
					</li><li class="span3">
						<div class="thumbnail">
							<div class="blockDtl">
							<h4>My web solutions</h4>
							<a href="comingsoon.html"><img src="bootstrap/img/portfolio/5.jpg" alt="bootstrap business templates"></a>
							<p>Our aim is simple - to provide affordable web design and development services for different devices. </p>
							<div class="btn-toolbar">
							   <div class="btn-group toolTipgroup">
								<a class="btn" href="#" data-placement="right" data-original-title="send email"><i class="icon-envelope"></i></a>
								<a class="btn" href="#" data-placement="top" data-original-title="do you like?"><i class="icon-thumbs-up"></i></a>
								<a class="btn" href="#" data-placement="top" data-original-title="dont like?"><i class="icon-thumbs-down"></i></a>
								<a class="btn" href="#" data-placement="top" data-original-title="share"><i class="icon-link"></i></a>
								<a href="comingsoon.html" class="btn" data-placement="left" data-original-title="browse"><i class="icon-globe"></i></a>
							  </div>
							</div>
							</div>
						</div>
					</li>
					<li class="span3">
						<div class="thumbnail">
							<div class="blockDtl">
							<h4>My web solutions</h4>
							<a href="http://mywebsolution.info" target="_blank"><img src="bootstrap/img/portfolio/6.jpg" alt="bootstrap business templates"></a>
							<p>Our aim is simple - to provide affordable web design and development services for different devices. </p>
							<div class="btn-toolbar">
							   <div class="btn-group toolTipgroup">
								<a class="btn" href="mailto:developer.sba@gmail.com" data-placement="right" data-original-title="send email"><i class="icon-envelope"></i></a>
								<a class="btn" href="#" data-placement="top" data-original-title="do you like?"><i class="icon-thumbs-up"></i></a>
								<a class="btn" href="#" data-placement="top" data-original-title="dont like?"><i class="icon-thumbs-down"></i></a>
								<a class="btn" href="#" data-placement="top" data-original-title="share"><i class="icon-link"></i></a>
								<a href="http://mywebsolution.info" target="_blank" class="btn" data-placement="left" data-original-title="browse"><i class="icon-globe"></i></a>
							  </div>
							</div>
							</div>
						</div>
					</li>
					</ul>
		<div class="pagination pagination-mini pull-right">
              <ul>
                <li><a href="#">�</a></li>
                <li><a href="#">1</a></li>
                <li><a href="#">2</a></li>
                <li><a href="#">3</a></li>
                <li><a href="#">4</a></li>
                <li><a href="#">5</a></li>
                <li><a href="#">�</a></li>
              </ul>
            </div>
		</div>
		<div class="tab-pane" id="popular">
		<ul class="thumbnails">			
					<li class="span3">
						<div class="thumbnail">
							<div class="blockDtl">
							<h4>My web solutions</h4>
							<a href="#"><img src="bootstrap/img/portfolio/7.jpg" alt="bootstrap business templates"></a>
							<p>Our aim is simple - to provide affordable web design and development services for different devices. </p>
							</div>
						</div>
					</li>
					<li class="span3">
						<div class="thumbnail">
							<div class="blockDtl">
							<h4>My web solutions</h4>
							<a href="#"><img src="bootstrap/img/portfolio/8.jpg" alt="bootstrap business templates"></a>
							<p>Our aim is simple - to provide affordable web design and development services for different devices. </p>
							</div>
						</div>
					</li>
					<li class="span3">
						<div class="thumbnail">
							<div class="blockDtl">
							<h4>My web solutions</h4>
							<a href="#"><img src="bootstrap/img/portfolio/9.jpg" alt="bootstrap business templates"></a>
							<p>Our aim is simple - to provide affordable web design and development services for different devices. </p>
							</div>
						</div>
					</li>
					<li class="span3">
						<div class="thumbnail">
							<div class="blockDtl">
							<h4>My web solutions</h4>
							<a href="#"><img src="bootstrap/img/portfolio/10.jpg" alt="bootstrap business templates"></a>
							<p>Our aim is simple - to provide affordable web design and development services for different devices. </p>
							</div>
						</div>
					</li>
					<li class="span3">
						<div class="thumbnail">
							<div class="blockDtl">
							<h4>My web solutions</h4>
							<a href="#"><img src="bootstrap/img/portfolio/11.jpg" alt="bootstrap business templates"></a>
							<p>Our aim is simple - to provide affordable web design and development services for different devices. </p>
							</div>
						</div>
					</li>
					<li class="span3">
						<div class="thumbnail">
							<div class="blockDtl">
							<h4>My web solutions</h4>
							<a href="#"><img src="bootstrap/img/portfolio/2.jpg" alt="bootstrap business templates"></a>
							<p>Our aim is simple - to provide affordable web design and development services for different devices. </p>
							</div>
						</div>
					</li>	
				</ul>
		</div>
		<div class="tab-pane" id="new">
		<ul class="thumbnails">
				<li class="span3">
						<div class="thumbnail">
							<div class="blockDtl">
							<h4>My web solutions</h4>
							<a href="#"><img src="bootstrap/img/portfolio/9.jpg" alt="bootstrap business templates"></a>
							<p>Our aim is simple - to provide affordable web design and development services for different devices. </p>
							<div class="btn-toolbar">
							   <div class="btn-group toolTipgroup">
								<a class="btn" href="#" data-placement="right" data-original-title="send email"><i class="icon-envelope"></i></a>
								<a class="btn" href="#" data-placement="top" data-original-title="do you like?"><i class="icon-thumbs-up"></i></a>
								<a class="btn" href="#" data-placement="top" data-original-title="dont like?"><i class="icon-thumbs-down"></i></a>
								<a class="btn" href="#" data-placement="top" data-original-title="share"><i class="icon-link"></i></a>
								<a class="btn" href="#" data-placement="left" data-original-title="browse"><i class="icon-globe"></i></a>
							  </div>
							</div>
							</div>
						</div>
					</li>
					<li class="span3">
						<div class="thumbnail">
							<div class="blockDtl">
							<h4>My web solutions</h4>
							<a href="#"><img src="bootstrap/img/portfolio/3.jpg" alt="bootstrap business templates"></a>
							<p>Our aim is simple - to provide affordable web design and development services for different devices. </p>
							<div class="btn-toolbar">
							   <div class="btn-group toolTipgroup">
								<a class="btn" href="#" data-placement="right" data-original-title="send email"><i class="icon-envelope"></i></a>
								<a class="btn" href="#" data-placement="top" data-original-title="do you like?"><i class="icon-thumbs-up"></i></a>
								<a class="btn" href="#" data-placement="top" data-original-title="dont like?"><i class="icon-thumbs-down"></i></a>
								<a class="btn" href="#" data-placement="top" data-original-title="share"><i class="icon-link"></i></a>
								<a class="btn" href="#" data-placement="left" data-original-title="browse"><i class="icon-globe"></i></a>
							  </div>
							</div>
							</div>
						</div>
					</li>
					<li class="span3">
						<div class="thumbnail">
							<div class="blockDtl">
							<h4>My web solutions</h4>
							<a href="http://mywebsolution.info" target="_blank"><img src="bootstrap/img/portfolio/6.jpg" alt="bootstrap business templates"></a>
							<p>Our aim is simple - to provide affordable web design and development services for different devices. </p>
							<div class="btn-toolbar">
							   <div class="btn-group toolTipgroup">
								<a class="btn" href="mailto:developer.sba@gmail.com" data-placement="right" data-original-title="send email"><i class="icon-envelope"></i></a>
								<a class="btn" href="#" data-placement="top" data-original-title="do you like?"><i class="icon-thumbs-up"></i></a>
								<a class="btn" href="#" data-placement="top" data-original-title="dont like?"><i class="icon-thumbs-down"></i></a>
								<a class="btn" href="#" data-placement="top" data-original-title="share"><i class="icon-link"></i></a>
								<a href="http://mywebsolution.info" target="_blank" class="btn" data-placement="left" data-original-title="browse"><i class="icon-globe"></i></a>
							  </div>
							</div>
							</div>
						</div>
					</li>
					<li class="span3">
						<div class="thumbnail">
							<div class="blockDtl">
							<h4>My web solutions</h4>
							<a href="comingsoon.html"><img src="bootstrap/img/portfolio/4.jpg" alt="bootstrap business templates"></a>
							<p>Our aim is simple - to provide affordable web design and development services for different devices. </p>
							<div class="btn-toolbar">
							   <div class="btn-group toolTipgroup">
								<a class="btn" href="#" data-placement="right" data-original-title="send email"><i class="icon-envelope"></i></a>
								<a class="btn" href="#" data-placement="top" data-original-title="do you like?"><i class="icon-thumbs-up"></i></a>
								<a class="btn" href="#" data-placement="top" data-original-title="dont like?"><i class="icon-thumbs-down"></i></a>
								<a class="btn" href="#" data-placement="top" data-original-title="share"><i class="icon-link"></i></a>
								<a href="comingsoon.html" class="btn" data-placement="left" data-original-title="browse"><i class="icon-globe"></i></a>
							  </div>
							</div>
							</div>
						</div>
					</li>
					<li class="span3">
					<div class="thumbnail">
						<h4>My web solutions</h4>
						<a href="#"><img src="bootstrap/img/portfolio/1.jpg" alt="bootstrap business templates"></a>
						<p>Our aim is simple - to provide affordable web design and development services for different devices. </p>
						<div class="btn-toolbar">
						  <div class="btn-group toolTipgroup">
							<a class="btn" href="#" data-placement="right" data-original-title="send email"><i class="icon-envelope"></i></a>
							<a class="btn" href="#" data-placement="top" data-original-title="do you like?"><i class="icon-thumbs-up"></i></a>
							<a class="btn" href="#" data-placement="top" data-original-title="dont like?"><i class="icon-thumbs-down"></i></a>
							<a class="btn" href="#" data-placement="top" data-original-title="share"><i class="icon-link"></i></a>
							<a class="btn" href="#" data-placement="left" data-original-title="browse"><i class="icon-globe"></i></a>
						  </div>
						</div>
					</div>
					</li>
					<li class="span3">
						<div class="thumbnail">
							<div class="blockDtl">
							<h4>My web solutions</h4>
							<a href="comingsoon.html"><img src="bootstrap/img/portfolio/5.jpg" alt="bootstrap business templates"></a>
							<p>Our aim is simple - to provide affordable web design and development services for different devices. </p>
							<div class="btn-toolbar">
							   <div class="btn-group toolTipgroup">
								<a class="btn" href="#" data-placement="right" data-original-title="send email"><i class="icon-envelope"></i></a>
								<a class="btn" href="#" data-placement="top" data-original-title="do you like?"><i class="icon-thumbs-up"></i></a>
								<a class="btn" href="#" data-placement="top" data-original-title="dont like?"><i class="icon-thumbs-down"></i></a>
								<a class="btn" href="#" data-placement="top" data-original-title="share"><i class="icon-link"></i></a>
								<a href="comingsoon.html" class="btn" data-placement="left" data-original-title="browse"><i class="icon-globe"></i></a>
							  </div>
							</div>
							</div>
						</div>
					</li>
					
					</ul>
		</div>
		<div class="tab-pane" id="comingsoon">
		<ul class="thumbnails">
			<li class="span3">
				<div class="thumbnail">
					<div class="blockDtl">
					<h4>My web solutions</h4>
					<a href="#"><img src="bootstrap/img/portfolio/9.jpg" alt="bootstrap business templates"></a>
					<p>Our aim is simple - to provide affordable web design and development services for different devices. </p>
					<div class="btn-toolbar">
					   <div class="btn-group toolTipgroup">
						<a class="btn" href="#" data-placement="right" data-original-title="send email"><i class="icon-envelope"></i></a>
						<a class="btn" href="#" data-placement="top" data-original-title="do you like?"><i class="icon-thumbs-up"></i></a>
						<a class="btn" href="#" data-placement="top" data-original-title="dont like?"><i class="icon-thumbs-down"></i></a>
						<a class="btn" href="#" data-placement="top" data-original-title="share"><i class="icon-link"></i></a>
						<a class="btn" href="#" data-placement="left" data-original-title="browse"><i class="icon-globe"></i></a>
					  </div>
					</div>
					</div>
				</div>
			</li>
			<li class="span3">
				<div class="thumbnail">
					<div class="blockDtl">
					<h4>My web solutions</h4>
					<a href="#"><img src="bootstrap/img/portfolio/3.jpg" alt="bootstrap business templates"></a>
					<p>Our aim is simple - to provide affordable web design and development services for different devices. </p>
					<div class="btn-toolbar">
					   <div class="btn-group toolTipgroup">
						<a class="btn" href="#" data-placement="right" data-original-title="send email"><i class="icon-envelope"></i></a>
						<a class="btn" href="#" data-placement="top" data-original-title="do you like?"><i class="icon-thumbs-up"></i></a>
						<a class="btn" href="#" data-placement="top" data-original-title="dont like?"><i class="icon-thumbs-down"></i></a>
						<a class="btn" href="#" data-placement="top" data-original-title="share"><i class="icon-link"></i></a>
						<a class="btn" href="#" data-placement="left" data-original-title="browse"><i class="icon-globe"></i></a>
					  </div>
					</div>
					</div>
				</div>
			</li>
			<li class="span3">
			<div class="thumbnail">
				<h4>My web solutions</h4>
				<a href="#"><img src="bootstrap/img/portfolio/1.jpg" alt="bootstrap business templates"></a>
				<p>Our aim is simple - to provide affordable web design and development services for different devices. </p>
				<div class="btn-toolbar">
				  <div class="btn-group toolTipgroup">
					<a class="btn" href="#" data-placement="right" data-original-title="send email"><i class="icon-envelope"></i></a>
					<a class="btn" href="#" data-placement="top" data-original-title="do you like?"><i class="icon-thumbs-up"></i></a>
					<a class="btn" href="#" data-placement="top" data-original-title="dont like?"><i class="icon-thumbs-down"></i></a>
					<a class="btn" href="#" data-placement="top" data-original-title="share"><i class="icon-link"></i></a>
					<a class="btn" href="#" data-placement="left" data-original-title="browse"><i class="icon-globe"></i></a>
				  </div>
				</div>
			</div>
			</li>
			
			<li class="span3">
				<div class="thumbnail">
					<div class="blockDtl">
					<h4>My web solutions</h4>
					<a href="comingsoon.html"><img src="bootstrap/img/portfolio/4.jpg" alt="bootstrap business templates"></a>
					<p>Our aim is simple - to provide affordable web design and development services for different devices. </p>
					<div class="btn-toolbar">
					   <div class="btn-group toolTipgroup">
						<a class="btn" href="#" data-placement="right" data-original-title="send email"><i class="icon-envelope"></i></a>
						<a class="btn" href="#" data-placement="top" data-original-title="do you like?"><i class="icon-thumbs-up"></i></a>
						<a class="btn" href="#" data-placement="top" data-original-title="dont like?"><i class="icon-thumbs-down"></i></a>
						<a class="btn" href="#" data-placement="top" data-original-title="share"><i class="icon-link"></i></a>
						<a href="comingsoon.html" class="btn" data-placement="left" data-original-title="browse"><i class="icon-globe"></i></a>
					  </div>
					</div>
					</div>
				</div>
			</li>
			<li class="span3">
				<div class="thumbnail">
					<div class="blockDtl">
					<h4>My web solutions</h4>
					<a href="comingsoon.html"><img src="bootstrap/img/portfolio/5.jpg" alt="bootstrap business templates"></a>
					<p>Our aim is simple - to provide affordable web design and development services for different devices. </p>
					<div class="btn-toolbar">
					   <div class="btn-group toolTipgroup">
						<a class="btn" href="#" data-placement="right" data-original-title="send email"><i class="icon-envelope"></i></a>
						<a class="btn" href="#" data-placement="top" data-original-title="do you like?"><i class="icon-thumbs-up"></i></a>
						<a class="btn" href="#" data-placement="top" data-original-title="dont like?"><i class="icon-thumbs-down"></i></a>
						<a class="btn" href="#" data-placement="top" data-original-title="share"><i class="icon-link"></i></a>
						<a href="comingsoon.html" class="btn" data-placement="left" data-original-title="browse"><i class="icon-globe"></i></a>
					  </div>
					</div>
					</div>
				</div>
			</li>
			<li class="span3">
				<div class="thumbnail">
					<div class="blockDtl">
					<h4>My web solutions</h4>
					<a href="http://mywebsolution.info" target="_blank"><img src="bootstrap/img/portfolio/6.jpg" alt="bootstrap business templates"></a>
					<p>Our aim is simple - to provide affordable web design and development services for different devices. </p>
					<div class="btn-toolbar">
					   <div class="btn-group toolTipgroup">
						<a class="btn" href="mailto:developer.sba@gmail.com" data-placement="right" data-original-title="send email"><i class="icon-envelope"></i></a>
						<a class="btn" href="#" data-placement="top" data-original-title="do you like?"><i class="icon-thumbs-up"></i></a>
						<a class="btn" href="#" data-placement="top" data-original-title="dont like?"><i class="icon-thumbs-down"></i></a>
						<a class="btn" href="#" data-placement="top" data-original-title="share"><i class="icon-link"></i></a>
						<a href="http://mywebsolution.info" target="_blank" class="btn" data-placement="left" data-original-title="browse"><i class="icon-globe"></i></a>
					  </div>
					</div>
					</div>
				</div>
			</li>
		</ul>
		</div>
	
	
	
	</div>
</div>
<!-- Footer
      ================================================== -->
	  <?php $this->load->view('footer');?>
	</style>
  </body>
</html>