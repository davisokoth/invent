<!DOCTYPE html>
<!--[if IE 6]>
<html id="ie6" class="ie"lang="en-US">
<![endif]-->
<!--[if IE 7]>
<html id="ie7"  class="ie"lang="en-US">
<![endif]-->
<!--[if IE 8]>
<html id="ie8"  class="ie"lang="en-US">
<![endif]-->
<!--[if IE 9]>
<html id="ie9"  class="ie"lang="en-US">
<![endif]-->
<!--[if gt IE 9]>
<html class="ie"lang="en-US">
<![endif]-->
<!--[if !IE]>
<html lang="en-US">
<![endif]-->

<!-- START HEAD -->
<head>
	@section('head')
    @include('head')
    @show
</head>
<!-- END HEAD -->

<!-- START BODY -->
<body>
@include('title-bar')

@yield('body')

<!-- START FOOTER -->

@include('footer')

<!-- END FOOTER -->

@section('footer')
@include('custom-script')
@show

</body>
<!-- END BODY -->
</html>
