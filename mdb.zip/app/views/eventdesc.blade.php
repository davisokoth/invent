@extends('layouts.main')
@section('head')
    @parent
    <title>ALIVE Kenya | Welcome</title>
@stop

@section('body')
<div id="primary" class="sidebar-right">
    <div class="container group">
        <div class="row">
            <!-- START CONTENT -->
            <div id="content-page" class="span12 content group">
                <div class="page type-page status-publish hentry group">
                    <div class="span8">
                        @if (Session::has('message'))
                            <div class="flash alert">
                                <p>{{ Session::get('message') }}</p>
                            </div>
                        @endif
                        <h2><a href="{{URL::route('events.list')}}">Events</a>: {{$event->name}}</h2>
                        <p>
                        Dates: {{$event->date}}<br />
                        Dates: {{$event->venue}}<br />
                        Costs: {{$event->cost}}</p>
                        {{$event->description}}
                    </div>
                    <div class="span3">
                        <div id="popular-posts-5" class="widget-2 widget-last widget popular-posts">
                                <h3>Coming Events</h3>
                                <div class="recent-post">
                                    <div class="post type-post status-publish format-gallery hentry category-web-design group">

                                        @foreach($events as $event)
                                            <div id="events" class="row">
                                                <div class="date">
                                                    <span class="month">{{date('M', strtotime($event->eventdate))}}</span>
                                                    <span class="day">{{date('d', strtotime($event->eventdate))}}</span>
                                                </div>

                                                <div class="text">
                                                    <h3>
                                                        <a href="{{URL::route('events.get', $event->id)}}" title="{{$event->title}}">
                                                            {{$event->name}}
                                                        </a>
                                                    </h3>
                                                </div>
                                            </div>
                                        @endforeach
                                    </div>
                                </div>
                            </div>
                    </div>
                </div>
                <!-- START COMMENTS -->
                <div id="comments"></div>
                <!-- END COMMENTS -->
            </div>

            <div class="border-line"></div>

            <div class="section ch-grid">
                    <!-- START EXTRA CONTENT -->
                    <div class="extra-content group span12">
                        <p>&nbsp;</p>
                        <p>&nbsp;</p>
                    </div>
                </div>
                <!-- END EXTRA CONTENT -->
            </div>

            <!-- END CONTENT -->

        </div>
    </div>
</div><!-- END PRIMARY -->
@stop

@section('footer')
    @parent

{{ HTML::script('js/medium-editor/medium-editor.js')}}

<script type="text/javascript">
<!--
    var editor = new MediumEditor('.editable');
    // initializing editors
    var titleEditor = new MediumEditor('.title-editable', {
        buttonLabels: 'fontawesome'
    });
    var bodyEditor = new MediumEditor('.body-editable', {
        buttonLabels: 'fontawesome'
    });
    $(function () {
        // initializing insert image on body editor
        $('.body-editable').mediumInsert({
            editor: bodyEditor,
            images: true,
            imagesUploadScript: "{{ URL::to('upload') }}"
        });
        // deactivate editors on show view
        if ($('#hideEditor').length) {
            $('.body-editable').mediumInsert('disable');
            bodyEditor.deactivate();
            titleEditor.deactivate();
        }
    });
    // hiding messages
    $('.error').hide().empty();
    $('.success').hide().empty();

    // create post
    $('body').on('submit', '#form-submit', function(e){
        alert 'Submit!';
        e.preventDefault();
        var postTitle = titleEditor.serialize();
        var postContent = bodyEditor.serialize();

        $.ajax({
            type: 'POST',
            dataType: 'json',
            url : "{{ URL::action('EventController@doNew') }}",
            data: { title: postTitle['post-title']['value'], body: postContent['post-body']['value'] },
            success: function(data) {
                if(data.success === false)
                {
                    $('.error').append(data.message);
                    $('.error').show();
                } else {
                    $('.success').append(data.message);
                    $('.success').show();
                    setTimeout(function() {
                        window.location.href = "{{ URL::action('EventController@home') }}";
                    }, 2000);
                }
            },
            error: function(xhr, textStatus, thrownError) {
                alert('Something went wrong. Please Try again later...');
            }
        });
        return false;
    });

    // update post
    $('body').on('click', '#form-update', function(e){
        e.preventDefault();
        var postTitle = titleEditor.serialize();
        var postContent = bodyEditor.serialize();

        $.ajax({
            type: 'PUT',
            dataType: 'json',
            url : "{{ URL::action('EventController@home', array(Request::segment(2))) }}",
            data: { title: postTitle['post-title']['value'], body: postContent['post-body']['value'] },
            success: function(data) {
                if(data.success === false)
                {
                    $('.error').append(data.message);
                    $('.error').show();
                } else {
                    $('.success').append(data.message);
                    $('.success').show();
                    setTimeout(function() {
                        window.location.href = "{{ URL::action('EventController@home') }}";
                    }, 2000);
                }
            },
            error: function(xhr, textStatus, thrownError) {
                alert('Something went wrong. Please Try again later...');
            }
        });
        return false;
    });
-->
</script>
@stop