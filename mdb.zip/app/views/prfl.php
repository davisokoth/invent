 	<!-- ================================================================ -->
	    <div class="row">
            <div class="block-content collapse in">
                <div class="span12">
                    <!-- Tabs -->
				<?php if(isset($result)){
					if($result=='fail'){?>
                    <div class="alert">
                        <button class="close" data-dismiss="alert">&times;</button>
                        <strong>Warning!</strong> Profile creation failed.
					</div>
                 <?php } else {?>
                    <div class="alert alert-success">
                        <button class="close" data-dismiss="alert">&times;</button>
                        <strong>Success!</strong> Profile was created.
                    </div>
                 <?php }}?>
		<div class="row show-grid">
			<div class="col-md-4">
				<!-- Thumbnails -->
				<div class="thumbnails">
					<img alt="" src="<?=$this->config->base_url()?>assets/img/pic.jpg">
					<ul class="list-group">
						<li class="list-group-item"><span class="icon-briefcase"></span>
                        <a href="#"><span class="badge">10</span>Completed Projects</a></li>
						<li class="list-group-item"><span class="icon-user"></span>
                        <a href="#"><span class="badge">14</span>Trusted Connections</a></li>
						<li class="list-group-item"><span class="icon-envelope"></span>
                        <a href="#"><span class="badge">11</span>Send Me a Message</a></li>
						<li class="list-group-item"><span class="icon-cog"></span> 
                        <a href="#">My Setings</a></li>
					</ul>
				</div><!-- /Thumbnails -->		
			</div>
			<div class="span8 right-block">
				<div class="info-block">
                	<?php if(isset($profile->title)){?>
					<h3><?=$profile->title?></h3>
					<p><?=$profile->description?></p>
                    <center><i class="icon-bullhorn"></i> <?=$profile->phone1?> | 
                    <i class="icon-bullhorn"></i> <?=$profile->phone2?> | 
                    <i class="icon-move"></i> <?=$profile->email?> | 
                    <i class="icon-resize"></i> <?=$profile->location?></center>
                    <ul class="social-icon">
						<?php if($profile->twitter!=''){?>
                        	<li><a href="<?=$profile->twitter?>" class="social twitter">
                            	<button class="btn-mini">twitter</button></a></li>
                        <?php }?>
						<?php if($profile->gplus!=''){?>
                            <li><button class="btn-mini">
                            <a href="<?=$profile->gplus?>" class="social google_plus">gplus</a></button></li>
						<?php }?>
						<?php if($profile->facebook!=''){?>
                            <li><button class="btn-mini">
                            <a href="<?=$profile->facebook?>" class="social facebook">facebook</a></button></li>
						<?php }?>
						<?php if($profile->skype!=''){?>
                            <li><button class="btn-mini">
                            <a href="<?=$profile->skype?>" class="social skype">skype</a></button></li>
						<?php }?>
						
						
					</ul>
				</div>
				<div class="content-text">
					<table class="table table-striped table-hover">
						<thead>
						  <tr>
							<th>Company</th><th>Descrition</th><th>Amount</th>
						  </tr>
						</thead>
						<tbody>
						  <tr>
							<td>Smart House</td>
							<td>Office furniture purchase</td>
							<td>$52560.10</td>
						  </tr>
						</tbody>
					</table>
					<?php } else {?>
                    <h3>Edit Profile</h3>
					<form class="form-horizontal" name="userrg" id="userrg" method="POST"
		action="<?=$this->config->base_url()?>index.php/profile/createnew" onsubmit="return validateLogin();">
           	<div class="span6">
				<div class="">
			        <div class="">
			            <label class="radio inline">
			                <input type="radio" value="1" name="iscompany"/>
			                Company Profile:
			            </label>
			            <label class="radio inline">
			                <input type="radio" value="2" name="iscompany"/>
			                Personal Profile:
			            </label>
					</div>
				</div>
				<div class="">
               		<input type="text" id="title" name="title" placeholder="Title" class="span5">
               	</div>
				<div class="">
               		<textarea id="description" name="description" class="span5" rows="6" 
					placeholder="Description"></textarea>
               	</div>
				<div class="">
               		<input type="text" id="phone1" name="phone1" placeholder="Phone No" class="span5">
               	</div>
				<div class="">
               		<input type="text" id="phone2" name="phone2" placeholder="Other Phone No" class="span5">
               	</div>
				<div class="">
               		<input type="text" id="email" name="email" placeholder="Email" class="span5">
               	</div>
				<div class="">
               		<input type="text" id="building" name="building" placeholder="Building" class="span5">
               	</div>
				<div class="">
               		<input type="text" id="street" name="street" placeholder="Street" class="span5">
               	</div>
				<div class="">
               		<input type="text" id="postadd" name="postadd" placeholder="Postal Address" class="span5">
               	</div>
				<div class="">
               		<input type="text" id="postcode" name="postcode" placeholder="Postal Code" class="span5">
               	</div>
				<div class="">
               		<input type="text" id="location" name="location" placeholder="Location" class="span5">
               	</div>
				<div class="">
               		<input type="text" id="city" name="city" placeholder="Town/City" class="span5">
               	</div>
				<div class="">
               		<input type="text" id="country" name="country" placeholder="Country" class="span5">
               	</div>
                <div class=""><hr /></div>
                <div class="">
               		<input type="text" id="twitter" name="twitter" placeholder="Twitter" class="span5">
               	</div>
				<div class="">
               		<input type="text" id="facebook" name="facebook" placeholder="Facebook" class="span5">
               	</div>
				<div class="">
               		<input type="text" id="gplus" name="gplus" placeholder="Google Plus" class="span5">
               	</div>
				<div class="">
               		<input type="text" id="skype" name="skype" placeholder="Skype" class="span5">
               	</div>
				<div class="col-lg-8">
					<input type="submit" class="btn btn-info" value="Create" name="create" id="create"/>
					<input type="button" class="btn btn-danger" value="Cancel" name="reset" id="reset"/>
					<br />
					<small>
						<input type="checkbox" name="tnc" id="tnc" class=""/>
							I have read the Terms of Use.<br />
					</small>
				</div>
				<div id="clear"></div>
				
           	</div>
			<input type="text" id="uncode" name="uncode" placeholder="uncode" class="invisible">
		</form>
					</table>
                    <?php }?>
				</div>				
			</div>
		</div>
            
                </div>
            </div>