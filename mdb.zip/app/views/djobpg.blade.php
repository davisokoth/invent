@extends('layouts.main')
@section('head')
    @parent
    <title>Advent Boutique | {{$job->name}}</title>

@stop

@section('body')

<div class="span9">
		<ul class="breadcrumb">
			<li>You are here: </li>
			<li><a href="index.php">Home</a></li>
			<li>\ <a href="{{url('listjobs')}}">List all</a></li>
			<li>\ {{$job->name}}</li>
		</ul>

		<!-- ================================================================= -->

		<!--
		<div class="thumbnail"><img src="bootstrap/img/banner.jpg" alt="#"/>
		-->

<!-- ======================================================================================================== -->
	<div class="thumbnail">
		<div class="caption">
			@if(!isset($job))
				<h4 class="text-warning">Content not found</h4>
				<p>The requested item was not found. Kindly go back and check the link</p>
			@else
				<h4>@<a href="{{url('profile/'.$job->user_id)}}">{{$job->first_name}}</a>:: {{$job->name}}</h4>
				<p class="smaller">
					Start Date: {{$job->created_on}} |
					Budget: KES. {{number_format("$job->budget",2,".",",")}} |
					No of bids: {{$job->nobids}} |
				</p>
				<p>{{$job->description}}</p>
				<p class="smaller">
					@if(isset($tags))
						@foreach($tags as $tagrow)
							<a href="#">{{$tagrow->name}}</a>,
						@endforeach
					@endif
				</p>
				<p>
				@if(Sentry::getUser()->id!=$job->user_id)
					@if(!isset($mybid))
						<a class="btn btn-primary" href="{{url('bid/newbid/'.$job->id)}}">
						&nbsp;&nbsp;&nbsp;<i class="icon-briefcase"></i> Bid&nbsp;&nbsp;&nbsp;</a>
					@else
						<a class="btn btn-primary" href="{{url('job/newbid/'.$job->id)}}">
						&nbsp;&nbsp;&nbsp;<i class="icon-briefcase"></i> My Bid&nbsp;&nbsp;&nbsp;</a>
					@endif
					<a class="btn btn-danger" href="{{URL::route('jobs.report', $job->id)}}">
						<i class="icon-warning-sign"></i> Report</a>
					<a class="btn btn-primary" href="{{url('job/sendmsg/'.$job->id)}}">
						<i class="icon-envelope"></i> Send PM</a>
	            @else
	        	</p>
	        	{{ Form::open(array( 'route' =>	'jobs.new' )) }}
		       	   	<div class="">
						<div class="">
					        <div class="">
		                   		<textarea id="description" name="description" class="span5" rows="6"  required=""
		    					placeholder="Details"></textarea>
		                   	</div>
		    				<div class="control-group">
		                          <label class="control-label" for="fileInput">File input</label>
		                          <div class="controls">
		                            <input class="input-file uniform_on" id="fileInput" type="file">
		                          </div>
		                    </div>
		    				<div class="col-lg-8">
		    					<input type="submit" class="btn btn-info" value="Create" name="create" id="create"/>
		    					<input type="button" class="btn btn-danger" value="Cancel" name="reset" id="reset"/>
		    					<br />
		    					<small>
		    						<input type="checkbox" name="tnc" id="tnc" class="" required="" />
		    							I have read the Terms of Use.<br />
		    					</small>
		    				</div>
		                    <div id="clear"></div>
		                </div>

		           	</div>
					<input type="text" id="uncode" name="uncode" placeholder="uncode" class="invisible">
				{{Form::close()}}
	        	@endif
	        	<p>

				<table id="bids" class="table table-bordered table-striped">
					@if(isset($comments))
						@foreach($comments as $bidrow)
						<tr>
							<td>
								<div class="smaller"><a href="#">{{$bidrow->user_name}}</a> |
								{{$bidrow->created_on}}</div>
							<br />{{$bidrow->description}}</td>
						</tr>
						@endforeach
					@endif
				</table>
			@endif
		</div>
	</div>
</div>
@stop