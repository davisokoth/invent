@extends('layouts.main')
@section('head')
    @parent
    <title>Advent Boutique | All Job</title>

@stop

@section('body')

	<div class="span9">
		<ul class="breadcrumb">
			<li>You are here: </li>
			<li><a href="index.php">Home</a></li>
			<li>:: Criteria</li>
		</ul>

		<!-- ================================================================= -->

		<!--
		<div class="thumbnail"><img src="bootstrap/img/banner.jpg" alt="#"/>
		-->

        <!-- ================================================================= -->
        @foreach($jobs as $job)
        <div class="thumbnail caption" id="thumb{{$job->id}}">
            <span class="pull-right">
                <a href="{{url('job/$job->id')}}"
                title="trash" data-placement="right" data-original-title="close">
                    <i class="icon-trash"></i></a> |
                    <a href="#" title="hide from list" data-placement="right" data-original-title="close">
                    <i class="icon-remove"></i>
                </a>
            </span>
            <h4>{{$job->isoffered=='Y'?'Available:':'Required:'}}
                <a href="{{url('job/get/'.$job->id)}}">{{$job->name}}</a>
            </h4>
            <p class="smaller">
                Posted by <a href="#">{{$job->first_name}}</a> | Starts: {{$job->startdate}} | Est. Budget:
                {{number_format("$job->budget",2,".",",")}} |
                Bids: {{$job->nobids}} |
                Escrow: {{$job->isescrow}} |
                Status: {{$job->status}}
            </p>
            <p>{{$job->description}}</p>
        </div>
        @endforeach
	</div>
    @stop