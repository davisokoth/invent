<!DOCTYPE html>
<html lang="en-US">
	<head>
		<meta charset="utf-8">
	</head>
	<body>
		<h2>Welcome to the Advent Boutique!</h2>

		<div>
			To activate your account kindly <a href="{{URL::to('home').'/activate/'.$activationcode }}">click here</a>
		</div>
	</body>
</html>
