<!-- HIDDEN PANEL 
================================================== -->
<div id="panel">
	<div class="row">
		<div class="twelve columns">
			<img src="images/info.png" class="pics" alt="info">
			<div class="infotext">
				<div class=" pull-right">
		            @if(!Sentry::check())
		                <a href="{{URL::route('auth.signup')}}">Register</a> |
		                <a href="{{URL::route('login')}}">Login</a>
		            @else
		                <?php
		                    $admin = Sentry::findGroupByName('SuperAdmins');
		                    $user = Sentry::getUser();
		                ?>
		                Welcome, <a href="">{{$user->first_name}}</a> |
		                <a href="{{URL::route('admin.home')}}">Admin Panel</a> |
		                <a href="{{URL::route('logout')}}">Logout</a> |
		            @endif
		            </div>
		        </div>
			</div>
		</div>
	</div>
</div>
<p class="slide">
	<a href="#" class="btn-slide"></a>
</p>
