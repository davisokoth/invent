@extends('layouts.main')
@section('head')
    @parent
@stop

@section('body')
<!--breadcrumbs start-->
    <div class="breadcrumbs">
      <div class="container">
        <div class="row">
          <div class="col-lg-4 col-sm-4"><h1>Login</h1></div>
          <div class="col-lg-8 col-sm-8">
          </div>
        </div>
      </div>
    </div>
    <!--breadcrumbs end-->

    <!--container start-->
    <div class="container">
      <div class="row">
        <!--blog start-->
        <div class="col-lg-12 well">
                @if (Session::has('message'))
                    <div class="flash alert">
                        <p>{{ Session::get('message') }}</p>
                    </div>
                @endif
                {{ Form::open(array( 'route'    =>  'auth.start' )) }}
                    <div class="span6 offset3">
                        <input type="text" id="email" name="email" placeholder="Email" required=""
                        value="{{Input::old('email')}}" autocomplete="off">
                        <input type="password" name="password" id="password" placeholder="Password" required=""
                        autocomplete="off" maxlength="13">
                        <div id="clear"></div>
                        <hr class="lighten">
                        <small><input type="checkbox" name="rem_me" id="rem_me" class=""/> Remember me.<br />
                        <div class="col-lg-8">
                            <input type="submit" class="btn btn-info" value="Login" name="login" id="login"/>
                            <input type="button" class="btn btn-danger" value="Cancel" name="reset" id="reset"/>
                        </div>
                        <div class="">
                            <a href="{{url('forgot')}}">Forgot Password?</a> |  <a href="{{url('register')}}">Register</a></small>
                        </div>
                    </div>
                {{Form::close()}}
                <p>&nbsp;</p>
                <p>&nbsp;</p>
        </div>
      </div>
    </div>
    <div class="border-line"></div>
  </div>
@stop
