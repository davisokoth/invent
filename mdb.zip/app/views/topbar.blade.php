<div id="topbar">
    <div class="container">
        <div class=" pull-right">
            @if(!Sentry::check())
                <a href="{{URL::route('auth.signup')}}">Register</a> |
                <a href="{{URL::route('login')}}">Login</a>
            @else
                <?php
                    $admin = Sentry::findGroupByName('SuperAdmins');
                    $user = Sentry::getUser();
                ?>
                Welcome, <a href="">{{$user->first_name}}</a> |
                <a href="{{URL::route('admin.home')}}">Admin Panel</a> |
                <a href="{{URL::route('logout')}}">Logout</a> |
            @endif
            </div>
        </div>
</div>