@section('content')
<h1>{{ $heading }}</h1>
<p>{{ $body }}</p>
<p>{{ $password }}</p>
@stop