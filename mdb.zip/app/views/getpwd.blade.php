@extends('layouts.blank')
@section('body')

<div class="row">
 	<div class="box dark">
        <header>
        	<div class="icons"><i class="fa fa-edit"></i></div>
            <h5>Forgot Password?</h5>
        </header>
    </div>
    
    <div id="" class="well span125 span-h-360 span-neg-10">
        {{Form::open(array('url'=>'/forgotpassword','method'=>'post'))}}
            <div class="span6 offset3">
                <input id="username" type="text" name="email" placeholder="Enter email" required="" 
                value="{{Input::old('email')}}" />
            </div><br />
            <div  class="span6 offset3">
                <input class="btn btn-info" type="submit" value="Reset Password" />
                <a href="/register">Register</a>
                <a href="/login">Login</a>
            </div>
        {{Form::close()}}
	</div>
</div>
<div id="clear"></div>
@stop