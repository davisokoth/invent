<div class="navbar">
  <div class="navbar-inner">
	<div class="container">
	  <div class="nav-collapse">
		<ul class="nav">
			<li class="active">
				<a href="{{URL::route('home')}}">Home</a></li>
			<li>
				<a href="{{URL::route('jobs.list.work')}}">Work</a></li>
			<li>
				<a href="{{URL::route('jobs.list.products')}}">Market</a></li>
			<li>
				<a href="{{URL::route('jobs.list')}}">Study</a></li>
			<li>
				<a href="{{URL::route('jobs.list')}}">Hangout</a></li>
		</ul>


		<ul class="nav pull-right">
        <!--<form action="#" class="navbar-search form-inline" style="margin-top:6px">
			<div class="input-append">
		  		<input type="text" placeholder="Search" />
				<button class="btn btn-warning"><i class="icon-search icon-white"></i></button>
			</div>
		</form>-->
			<li class="dropdown">
		  		<a data-toggle="dropdown" class="dropdown-toggle" href="#">
					<b class="caret"></b> {{(Sentry::getUser()->email ? Sentry::getUser()->first_name : 'Anonymous') }}
				</a>
		  		<ul class="dropdown-menu">
			  		<li><a href="{{URL::route('me')}}">Profile</a></li>
			  		<li><a href="{{URL::route('logout')}}">Logout</a></li>
		  		</ul>
		  	</li>
			<li><a href="{{URL::route('messages')}}"><i class="icon-envelope"></i></a></li>
			<li><a href="{{URL::route('notifications')}}"><i class="icon-bell"></i></a></li>
			<li><a href="{{URL::route('help')}}"><i class="icon-question-sign"></i></a></li>
		</ul>
	  </div><!-- /.nav-collapse -->
	</div>
  </div><!-- /navbar-inner -->
</div>
