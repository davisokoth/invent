@extends('layouts.main')
@section('head')
    @parent
@stop

@section('body')
<!--breadcrumbs start-->
    <div class="breadcrumbs">
      <div class="container">
        <div class="row">
          <div class="col-lg-4 col-sm-4">
            <h1>
              About us
            </h1>
          </div>
          <div class="col-lg-8 col-sm-8">
            <ol class="breadcrumb pull-right">
              <li>
                <a href="#">
                  Home
                </a>
              </li>
              <li class="active">
                About
              </li>
            </ol>
          </div>
        </div>
      </div>
    </div>
    <!--breadcrumbs end-->

<div class="container">
      <div class="row">
        <div class="col-lg-5">
          <div class="about-carousel wow fadeInLeft">
            <div id="myCarousel" class="carousel slide">
              <!-- Carousel items -->
              <div class="carousel-inner">
                <div class="active item">
					{{ HTML::image('img/indian-ink.jpg', 'a picture', array('class' => '')) }}
                  <div class="carousel-caption">
                    <p>
                      Lorem ipsum dolor sit amet.
                    </p>
                  </div>
                </div>
                <div class="item">
                  {{ HTML::image('img/books.jpg', 'a picture', array('class' => '')) }}
                  <div class="carousel-caption">
                    <p>
                      Blanditiis praesentium voluptatum
                    </p>
                  </div>
                </div>
              </div>
              
              <!-- Carousel nav -->
              <a class="carousel-control left" href="#myCarousel" data-slide="prev">
                <i class="fa fa-angle-left">
                </i>
              </a>
              <a class="carousel-control right" href="#myCarousel" data-slide="next">
                <i class="fa fa-angle-right">
                </i>
              </a>
            </div>
          </div>
        </div>
        <div class="col-lg-7 about wow fadeInRight">

          <h3>What is behind the name ‘Mentoring Visions Publishers? </h3>
		  <p>Kenya is made up of vision bearing individuals who would see more of their desired results if their 
		  dreams were mentored. We are talking about a talented author who perhaps hasn’t recognized his full
		  potential or a person with a story who may not be in a position to put it into writing. VISP takes the
		  pleasure in identifying such and points them to a ladder leading to their dreams through publishing.</p>
          <ul class="list-unstyled">
			  <li> 
				  <i class="fa fa-angle-right pr-10"></i>
				  Mission:<br /> To deliver excellence in religious, secular and academic publishing and to be an integral partner for authors and professional communities.
			  </li>
			  <li> 
				  <i class="fa fa-angle-right pr-10"></i>
				  Vision:<br /> To provide quality and affordable publishing services that exceeds the expectations of our esteemed customers.
			  </li>
			  <li> 
				  <i class="fa fa-angle-right pr-10"></i>
				  Commitment:<br /> We are committed to mentoring your vision of publishing and our word is our commitment.
			  </li>
			  <li> 
				  <i class="fa fa-angle-right pr-10"></i>
				  Values:<br /> Integrity, Professionalism, Excellency
			  </li>
          </ul>
          <blockquote>
            <p>
              We bring a personal and effective approach to every project we work on.
            </p>
            <small>
              Leakey Mokua (CEO)
            </small>
          </blockquote>
        </div>
      </div>
      
    </div>

    <div class="gray-box">
      <div class="container">
        <div class="row">
          <div class="col-lg-5">
            <!--testimonial start-->
            <div class="about-testimonial boxed-style about-flexslider ">
              <section class="slider wow fadeInRight">
                <div class="flexslider">
                  <ul class="slides about-flex-slides">
                    <li>
                      <div class="about-testimonial-image ">
						  {{ HTML::image('img/team/member2.jpg', 'a picture', array('class' => '')) }}
                      </div>
                      <a class="about-testimonial-author" href="#">
                        Leakey Mokua Nyaberi
                      </a>
                      <span class="about-testimonial-company">
                        CEO
                      </span>
                      <div class="about-testimonial-content">
                        <p class="about-testimonial-quote">
                          We assure you of quality services that are provided in a timely and efficient manner. You have a publishing dream? Contact us!
                        </p>
                      </div>
                    </li>
                    <li>
                      <div class="about-testimonial-image ">
						  {{ HTML::image('img/team/member3.jpg', 'a picture', array('class' => '')) }}
                      </div>
                      <a class="about-testimonial-author" href="#">
                        Ruth Rehema
                      </a>
                      <span class="about-testimonial-company">
                        Head, Product Development
                      </span>
                      <div class="about-testimonial-content">
                        <p class="about-testimonial-quote">
                          We have entered the publishing market to demystify the notion that publishing is a preserve of a few well financially oiled individuals.
                          We do all types of literature and work with you to ensure that all you need to communicate is captured in your book in a more professional manner.
                        </p>
                      </div>
                    </li>
                  </ul>
                </div>
              </section>
            </div>
            <!--testimonial end-->
          </div>
          <div class="col-lg-7" id="skillz">
            <h3 class="skills">
              Works we've completed
            </h3>

            <div class="skill_bar">
              <div class="skill_bar_progress skill_one">
                <p>
                  Book Covers
                </p>
              </div>
            </div>

            <div class="skill_bar">
              <div class="skill_bar_progress skill_two">
                <p>
                  Editing
                </p>
              </div>
            </div>

            <div class="skill_bar">
              <div class="skill_bar_progress skill_three">
                <p>
                  Layout and Design
                </p>
              </div>
            </div>

            <div class="skill_bar">
              <div class="skill_bar_progress skill_four">
                <p>
                  Ghost Writing
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
@stop
