@extends('layouts.main')
@section('head')
    @parent
@stop

@section('body')
<!--breadcrumbs start-->
    <div class="breadcrumbs">
      <div class="container">
        <div class="row">
          <div class="col-lg-4 col-sm-4"><h1>Articles</h1></div>
          <div class="col-lg-8 col-sm-8">
            <ol class="breadcrumb pull-right">
              <li><a href="#">Home</a></li>
              <li><a href="#">Blog</a></li>
            </ol>
          </div>
        </div>
      </div>
    </div>
    <!--breadcrumbs end-->

    <!--container start-->
    <div class="container">
      <div class="row">
        <!--blog start-->
        <div class="col-lg-9">
           <h1>{{$blog->title}}</h1>
           <p>{{date('D, d M Y', strtotime($blog->created_at))}} ||
           By {{$blog->user->first_name.' '.$blog->user->last_name}} || {{$blog->numberviews}} views</p>
	   <div id="imgdiv">{{HTML::image('images/blog/'.$blog->blogimage)}}</div>
           <div class="span8">
              {{$blog->entry}}
           </div>
	   <p>&nbsp;</p>
        </div>

	<div class="col-lg-3 sidebar">
              <h3>
                Latest Blog Post
              </h3>
	      @foreach($blogs as $blogentry)
              <div class="media">
                <a class="pull-left" href="javascript:;">
                  {{HTML::image('img/blog/blog-thumb-1.jpg')}}
                </a>
                <div class="media-body">
                  <h5 class="media-heading">
                    <a href="javascript:;">
                      {{date('D, d M Y', strtotime($blogentry->publishdate))}}
                    </a>
                  </h5>
                  <p>
                    {{$blogentry->title}}
                  </p>
                </div>
              </div>
	      @endforeach
            </div>
    </div>
</div>

@stop
