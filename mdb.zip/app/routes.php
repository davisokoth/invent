<?php

/*
|--------------------------------------------------------------------------
| Application Routes
|--------------------------------------------------------------------------
|
*/

 // **********************************************************************************
 // Test Section *********************************************************************
 // **********************************************************************************
Route::get('/', array(
	'uses' => 'WelcomeController@home',
	'as' => 'home')
);

Route::get('about', array(
    'uses' => 'WelcomeController@about',
    'as' => 'about')
);

Route::get('faq', array(
    'uses' => 'WelcomeController@faq',
    'as' => 'faq')
);

Route::get('pricing', array(
    'uses' => 'WelcomeController@pricing',
    'as' => 'pricing')
);

Route::get('help', array(
  'uses' => 'WelcomeController@home',
  'as' => 'help')
);

Route::get('events', array(
  'uses' => 'EventController@home',
  'as' => 'events')
);

Route::get('contact', array(
  'uses' => 'WelcomeController@contact',
  'as' => 'contact')
);


Route::group(array('before' => 'check_login'), function(){

  Route::get('activate', array(
    'uses' => 'WelcomeController@activate',
    'as' => 'activate')
  );

  Route::get('notifications', array(
    'uses' => 'WelcomeController@home',
    'as' => 'notifications')
  );

  Route::get('admin', array(
    'uses' => 'WelcomeController@admin',
    'as' => 'admin.home')
  );

  Route::get('myprofile', array(
    'uses' => 'ProfileController@home',
    'as' => 'me')
  );

  Route::get('messages', array(
    'uses' => 'WelcomeController@home',
    'as' => 'messages')
  );
});

Route::get('register', array(
  'uses' => 'WelcomeController@register',
  'as' => 'register')
);

Route::get('forgot', function(){
  return View::make('getpwd');
});

Route::post('auth/start', array(
  'uses' => 'AuthController@start',
  'as' => 'auth.start'
));

Route::get('logout', array(
  'uses' => 'AuthController@getLogout',
  'as' => 'logout'
));

Route::post('auth/register', array(
  'uses' => 'AuthController@register',
  'as' => 'auth.register'
));


Route::get('login', array(
    'uses' => 'AuthController@init',
    'as' => 'login')
);

Route::get('auth/signup', array(
    'uses' => 'AuthController@signup',
    'as' => 'auth.signup')
);

// ************ BLOGS **************************

Route::group(array('prefix' => 'blog'), function(){
  Route::get('/list', array(
    'uses' => 'BlogController@home',
    'as' => 'blogs.list'
  ));

  Route::get('/new', array(
    'uses' => 'BlogController@start',
    'as' => 'blogs.new'
  ));

  Route::post('/start', array(
    'uses' => 'BlogController@doNew',
    'as' => 'blogs.start'
  ));

  Route::get('/get/{id}', array(
    'uses' => 'BlogController@getBlog',
    'as' => 'blogs.get'
  ));

  Route::get('/report/{id}', array(
    'uses' => 'BlogController@report',
    'as' => 'blogs.report'
  ));
});

// ************ EVENTS **************************

Route::get('event/get/{id}', array(
  'uses' => 'EventController@getevent',
  'as' => 'events.get'
));

Route::get('event/list', array(
  'uses' => 'EventController@home',
  'as' => 'events.list'
));


Route::group(array('prefix' => 'event', 'before' => 'check_login'), function(){
  Route::get('/new', array(
    'uses' => 'EventController@start',
    'as' => 'events.new'
  ));

  Route::post('/start', array(
    'uses' => 'EventController@doNew',
    'as' => 'events.start'
  ));

  Route::get('/report/{id}', array(
    'uses' => 'EventController@report',
    'as' => 'events.report'
  ));
});



