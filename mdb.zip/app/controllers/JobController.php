<?php

use Illuminate\Support\MessageBag;

class JobController extends BaseController {

	private $messageBag;

	public function __construct(){
		$messageBag= new MessageBag;
	}

	public function home()
	{
		if (!Sentry::check())
		{
			// return View::make('lgnpg');
		}
		$jobs = Job::with('user')->
		leftJoin('users', 'users.id', '=', 'jobs.user_id')->
		select(DB::raw('users.id, users.first_name, jobs.*,
			(SELECT count(job_id) FROM bids WHERE job_id=jobs.id) as nobids'))->
		orderby('jobs.updated_at', 'desc')->paginate(20);
	    return View::make('jobslist')->with('jobs', $jobs);
	}

	public function work()
	{
		if (!Sentry::check())
		{
			// return View::make('lgnpg');
		}

		// $users = User::where_in('id', array(1, 2, 3))->or_where('email', '=', $email)->get();

		$jobs = Job::with('user')->
		leftJoin('users', 'users.id', '=', 'jobs.user_id')->
		select(DB::raw('users.id, users.first_name, jobs.*,
			(SELECT count(job_id) FROM bids WHERE job_id=jobs.id) as nobids'))->
		whereIsJobAndIsOffered('Y', 'N')->
		orderby('jobs.updated_at', 'desc')->paginate(20);
	    return View::make('jobslist')->with('jobs', $jobs);
	}

	public function products()
	{
		if (!Sentry::check())
		{
			// return View::make('lgnpg');
		}
		$jobs = Job::with('user')->
		leftJoin('users', 'users.id', '=', 'jobs.user_id')->
		select(DB::raw('users.id, users.first_name, jobs.*,
			(SELECT count(job_id) FROM bids WHERE job_id=jobs.id) as nobids'))->
		whereIsJobAndIsOffered('N', 'N')->
		orderby('jobs.updated_at', 'desc')->paginate(20);
	    return View::make('jobslist')->with('jobs', $jobs);
	}

	public function start()
	{
		if (!Sentry::check())
		{
			return View::make('lgnpg');
		}
		$categories = Category::lists('name', 'id');
		return View::make('nwjbpg')->with(array('categories'=>$categories));
		// return View::make('date-test');
	}

	public function doNew()
	{
		if (!Sentry::check())
		{
			return View::make('lgnpg');
		}
		$rules = array(
			'name'		       => 'required|min:3',
			'description'      => 'required|min:3',
			'budget'           => 'numeric',
		);

		// Create a new validator instance from our validation rules
		$validator = Validator::make(Input::all(), $rules);

		// If validation fails, we'll exit the operation now.
		if ($validator->fails())
		{
			// Ooops.. something went wrong
			return Redirect::back()->withInput()->withErrors($validator);
		}

		// Register the user
		$job = new Job;
		$job->name     		= Input::get('name');
		$job->description 	= Input::get('description');
		$job->isoffered		= Input::get('isoffered')==1?'Y':'N';
		$job->isjob			= Input::get('isjob')==1?'Y':'N';
		$job->isescrow		= Input::get('isescrow')==1?'Y':'N';
		$job->category 		= Input::get('category');
		$job->iscontract	= 'N';
		$job->status		= 1;
		$job->active		= 'Y';
		$job->budget		= Input::get('budget');
		$job->startdate		= date('Y-m-d', strtotime(Input::get('startdate')));
		$job->enddate		= date('Y-m-d', strtotime(Input::get('enddate')));
		$job->user_id		= Sentry::getUser()->id;

		$job->save();

		$insertedId = $job->id;


		// Ooops.. something went wrong
		if($insertedId==null) return Redirect::back()->withInput()->withErrors('Saving failed!');
		return View::make('nwjbpg');
	}

	public function getjob($id)
	{
		if (!Sentry::check())
		{
			// return View::make('lgnpg');
		}
		$job = Job::with('user')->
			leftJoin('users', 'users.id', '=', 'jobs.user_id')->
			select(DB::raw('users.id, users.first_name, jobs.*,
				(SELECT count(job_id) FROM bids WHERE job_id=jobs.id) as nobids,
				(SELECT count(job_id) FROM comments WHERE job_id=jobs.id) as nocomments'))->
			where('jobs.id', $id)->first();
		$comments = Comment::with('job')->select('comments.*')->where('job_id', $id)->orderby('created_at')->get();
		$bids = Bid::with('job')->select('bids.*')->where('job_id', $id)->orderby('created_at')->get();
		$tags = Tag::with('jobs_tags')->
			leftJoin('jobs', 'jobs.id', '=', 'tags.job_id')->
			select('tags.*')->where('job_id', $id)->orderby('created_at')->get();
	    return View::make('djobpg')->with(array('job'=>$job, 'comments'=>$comments, 'bids'=>$bids));
	}

	public function report($id)
	{
		if (!Sentry::check())
		{
			// return View::make('lgnpg');
		}
		$job = Job::with('user')->
			leftJoin('users', 'users.id', '=', 'jobs.user_id')->
			select(DB::raw('users.id, users.first_name, jobs.*,
				(SELECT count(job_id) FROM bids WHERE job_id=jobs.id) as nobids,
				(SELECT count(job_id) FROM comments WHERE job_id=jobs.id) as nocomments'))->
			where('jobs.id', $id)->first();
		$comments = Comment::with('job')->select('comments.*')->where('job_id', $id)->orderby('created_at')->get();
		$bids = Bid::with('job')->select('bids.*')->where('job_id', $id)->orderby('created_at')->get();
		$tags = Tag::with('jobs_tags')->
			leftJoin('jobs', 'jobs.id', '=', 'tags.job_id')->
			select('tags.*')->where('job_id', $id)->orderby('created_at')->get();
	    return View::make('djobpg')->with(array('job'=>$job, 'comments'=>$comments, 'bids'=>$bids));
	}

	// --------------------------------------------------------------
}
/* End of file welcome.php */
/* Location: ./application/controllers/welcome.php */