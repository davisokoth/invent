<?php

use Illuminate\Support\MessageBag;

class ProfileController extends BaseController {

	private $messageBag;

	public function __construct(){
		$messageBag= new MessageBag;
	}

	public function home()
	{
		if (!Sentry::check())
		{
			// return View::make('lgnpg');
		}
		$profiles = Profile::with('user')->
		leftJoin('users', 'users.id', '=', 'profiles.user_id')->
		select('profiles.*')->
		where('user_id', Sentry::getUser()->id)->
		orderby('profiles.updated_at', 'desc')->paginate(20);
	    return View::make('viewprfl')->with('profiles', $profiles);
	}

	public function start()
	{
		if (!Sentry::check())
		{
			return View::make('lgnpg');
		}
		return View::make('nwjbpg');
		// return View::make('date-test');
	}

	public function donew()
	{
		if (!Sentry::check())
		{
			return View::make('lgnpg');
		}
		$rules = array(
			'title'		       => 'required|min:3',
			'description'      => 'required|min:3',
			'phone1'           => 'required|min:10|max:20',
			'email'            => 'required|email',
			'is_company'       => 'required',
			'city'             => 'required',
			'country'          => 'required',
		);

		// Create a new validator instance from our validation rules
		$validator = Validator::make(Input::all(), $rules);

		// If validation fails, we'll exit the operation now.
		if ($validator->fails())
		{
			// Ooops.. something went wrong
			return Redirect::back()->withInput()->withErrors($validator);
		}

		// Create the Profile
		$profile = new Profile;
		$profile->title     	= Input::get('title');
		$profile->description 	= Input::get('description');
		$profile->is_company	= Input::get('is_company');
		$profile->phone1		= Input::get('phone1');
		$profile->phone2		= Input::get('phone2');
		$profile->email  		= Input::get('email');
		$profile->street		= Input::get('street');
		$profile->postadd		= Input::get('postadd');
		$profile->postcode		= Input::get('postcode');
		$profile->city			= Input::get('city');
		$profile->country_id		= 100; //Input::get('country');
		$profile->facebook		= Input::get('facebook');
		$profile->twitter		= Input::get('twitter');
		$profile->gplus			= Input::get('gplus');
		$profile->skype			= Input::get('skype');
		$profile->is_default	= 'Y';
		$profile->active 		= 'Y';

		$profile->user_id		= Sentry::getUser()->id;

		$profile->save();

		$insertedId = $profile->id;


		// Ooops.. something went wrong
		if($insertedId==null) return Redirect::back()->withInput()->withErrors('Saving failed!');
		// return View::make('viewprfl');
		$this->home();
	}

	public function get($id)
	{
		if (!Sentry::check())
		{
			// return View::make('lgnpg');
		}

	}

	public function report($id)
	{
		if (!Sentry::check())
		{
			// return View::make('lgnpg');
		}

	}

	// --------------------------------------------------------------
}
/* End of file welcome.php */
/* Location: ./application/controllers/welcome.php */