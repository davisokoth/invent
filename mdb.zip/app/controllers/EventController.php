<?php

use Illuminate\Support\MessageBag;

class EventController extends BaseController {

	private $messageBag;

	public function __construct(){
		$messageBag= new MessageBag;
	}

	public function home()
	{
		if (!Sentry::check())
		{
			// return View::make('login');
		}
		$events = Program::orderby('eventdate', 'desc')->take(20)->get();
	    return View::make('eventlist')->with('events', $events);
	}

	public function start()
	{
		return View::make('newevent');
	}

	public function doNew()
	{
		if (!Sentry::check())
		{
			return View::make('login');
		}
		$rules = array(
			'name'		       	=> 'required|min:3',
			'cost'           	=> 'numeric|required',
			'venue'           	=> 'required',
			'eventdate'        	=> 'required',
		);

		// Create a new validator instance from our validation rules
		$validator = Validator::make(Input::all(), $rules);

		// If validation fails, we'll exit the operation now.
		if ($validator->fails())
		{
			// Ooops.. something went wrong
			return Redirect::back()->withInput()->withErrors($validator);
		}

		// Register the user
		$event = new Program;
		$event->name     		= Input::get('name');
		$event->venue			= Input::get('venue');
		$event->cost			= Input::get('cost');
		$event->eventdate		= date('Y-m-d', strtotime(Input::get('eventdate')));
		$event->user_id			= Sentry::getUser()->id;
		$event->description 	= Input::get('description');
		$event->isactive			= 'Y';

		$event->save();
		$insertedId = $event->id;


		// Ooops.. something went wrong
		if($insertedId==null) return Redirect::back()->withInput()->withErrors('Saving failed!');

		$events = Meeting::orderby('eventdate', 'desc')->take(20)->get();
	    return View::make('eventlist')->with('events', $events);
	}

	public function getevent($id)
	{
		
		$event = Program::findOrFail($id);
		$events = Program::orderby('eventdate', 'desc')->take(5)->get();
		return View::make('eventdesc')->with(array('event'=>$event, 'events' => $events));
	}

	public function report($id)
	{
		if (!Sentry::check())
		{
			// return View::make('login');
		}

	    return View::make('deventpg')->with(array('event'=>$event, 'comments'=>$comments, 'bids'=>$bids));
	}

	public function upload()
    {
        $file = Input::file('file');
        $input = array('image' => $file);
        $rules = array(
            'image' => 'image'
        );
        $validator = Validator::make($input, $rules);
        if ( $validator->fails()) {
            return Response::json(array('success' => false, 'errors' => $validator->getMessageBag()->toArray()));
        }

        $fileName = time() . '-' . $file->getClientOriginalName();
        $destination = public_path() . '/uploads/';
        $file->move($destination, $fileName);

        echo url('/uploads/'. $fileName);
    }

    public function update()
    {
    	$input = array_except(Input::all(), '_method');
        $validation = Validator::make($input, Post::$rules);

        if ($validation->passes())
        {
            $event = Program::find($id);
            $event->update($input);

            return Response::json(array('success' => true, 'errors' => '',
            	'message' => 'Event updated successfully.'));
        }

        return Response::json(array('success' => false, 'errors' => $validation,
        	'message' => 'All fields are required.'));
    }

	// --------------------------------------------------------------
}
/* End of file welcome.php */
/* Location: ./application/controllers/welcome.php */