<?php

use Illuminate\Support\MessageBag;

class TagController extends BaseController {

	private $messageBag;

	public function __construct(){
		$messageBag= new MessageBag;
	}

	public function home()
	{
		if (!Sentry::check())
		{
			return View::make('login');
		}
		$tags = Tag::with('job')->orderby('tags.updated_at', 'desc')->paginate(20);
	    return View::make('tagslist')->with('tags', $tags);
	}

	public function start()
	{
		if (!Sentry::check())
		{
			return View::make('login');
		}
		return View::make('nwtag');
	}

	public function donew()
	{
		if (!Sentry::check())
		{
			return View::make('login');
		}
		$rules = array(
			'name'		       => 'required|min:3',
			'description'      => 'required|min:3',
		);

		// Create a new validator instance from our validation rules
		$validator = Validator::make(Input::all(), $rules);

		// If validation fails, we'll exit the operation now.
		if ($validator->fails())
		{
			// Ooops.. something went wrong
			return Redirect::back()->withInput()->withErrors($validator);
		}

		// Register the job
		$tag = new Tag;
		$tag->name     		= Input::get('name');
		$tag->description 	= Input::get('description');
		$tag->active		= 'Y';

		$tag->save();

		$insertedId = $tag->id;


		// Ooops.. something went wrong
		if($insertedId==null) return Redirect::back()->withInput()->withErrors('Saving failed!');
		return View::make('nwjbpg');
	}

	public function gettag($id)
	{
		if (!Sentry::check())
		{
			return View::make('login');
		}
		$tag = Tag::with('job')->
			where('tags.id', $id)->first();
		return View::make('dtagpg')->with(array('tag'=>$tag));
	}

	// --------------------------------------------------------------
}
/* End of file welcome.php */
/* Location: ./application/controllers/welcome.php */