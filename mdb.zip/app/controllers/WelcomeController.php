<?php
class WelcomeController extends BaseController {

	public function home()
	{
		$blogs = Blog::with('user')
		->leftJoin('users', 'users.id', '=', 'blogs.author')
		->where('ispublished', 'Y')
		->take(5)
		->orderBy('publishdate', 'desc')
		->get();
		$events = Program::where('isactive', 'Y')->take(5)->orderBy('created_at', 'desc')->get();
	    return View::make('home')->with(array('blogs' => $blogs, 'events' => $events));
	}

	public function about()
	{
		return View::make('about');
	}

	public function faq()
	{
		return View::make('faq');
	}

	public function pricing()
	{
		return View::make('pricing');
	}

	public function profile()
	{
		return View::make('prfl');
	}

	public function contact()
	{
		return View::make('contact');
	}

	public function admin()
	{
		if (!Sentry::check())
		{
			return View::make('login');
		}
		return View::make('admin');
	}

	// --------------------------------------------------------------
}
/* End of file welcome.php */
/* Location: ./application/controllers/welcome.php */
