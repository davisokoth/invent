<?php

use Illuminate\Support\MessageBag;

class SongController extends BaseController {

	private $messageBag;

	public function __construct(){
		$messageBag= new MessageBag;
	}

	public function home()
	{
		$songs = Media::all()->orderBy('created_on')->take(5)->get();
	    return View::make('jobslist')->with('jobs', $songs);
	}

	public function start()
	{
		$albums = Album::lists('title', 'id');
		return View::make('nwjbpg')->with(array('albums'=>$albums));
		// return View::make('date-test');
	}

	public function doNew()
	{
		$rules = array(
			'name'		       => 'required|min:3',
			'description'      => 'required|min:3',
			'storedname'       => 'required|min:3',
			'album_id'		   => 'numeric|required'
		);

		// Create a new validator instance from our validation rules
		$validator = Validator::make(Input::all(), $rules);

		// If validation fails, we'll exit the operation now.
		if ($validator->fails())
		{
			// Ooops.. something went wrong
			return Redirect::back()->withInput()->withErrors($validator);
		}

		// Register the user
		$song = new Song;
		$song->name     		= Input::get('name');
		$song->description 		= Input::get('description');
		$song->rating 			= 0;
		$song->event_id			= Input::get('event_id');
		$song->status			= 1;
		$song->active			= 'Y';
		$song->storedname		= Input::get('budget');
		$song->startdate		= date('Y-m-d', strtotime(Input::get('startdate')));
		$song->enddate			= date('Y-m-d', strtotime(Input::get('enddate')));
		$song->user_id			= Sentry::getUser()->id;

		$song->save();

		$insertedId = $song->id;


		// Ooops.. something went wrong
		if($insertedId==null) return Redirect::back()->withInput()->withErrors('Saving failed!');
		return View::make('nwjbpg');
	}

	public function getsong($id)
	{
		$song = Media::find($id);
		$author = $song->author;
		$program = $song->program;
		$album = $song->album;
		$othersongs = DB::select('select * from medias where album_id = ?', array($song->album_id));
		$tags = DB::select('select * from tags where id in (select tag_id from tags_medias where media_id = ?)', array($song->id));
		//$comments = Comment::with('media')->select('comments.*')->where('song_id', $id)->orderby('created_at')->get();
		return View::make('music')->with(array('song'=>$song, 'author'=>$author, 'program'=>$program,
			'album'=>$album, 'othersongs' => $othersongs, 'tags' => $tags));
	}

	public function report($id){}

	// --------------------------------------------------------------
}
/* End of file welcome.php */
/* Location: ./application/controllers/welcome.php */