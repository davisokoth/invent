<?php
class User extends Eloquent {

}