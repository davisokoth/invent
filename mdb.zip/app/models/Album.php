<?php
class Album extends Eloquent {

}