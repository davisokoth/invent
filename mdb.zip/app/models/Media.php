<?php

class Media extends Eloquent{

    public function program()
    {
        return $this->belongsTo('Program');
    }

    public function album()
    {
        return $this->belongsTo('Album');
    }

    public function user()
    {
        return $this->belongsTo('User');
    }

    public function author()
    {
        return $this->belongsTo('Author');
    }

    public function comments()
    {
        return $this->hasMany('Comment');
    }

    public function tags()
    {
        return $this->hasMany('Tag');
    }
}
