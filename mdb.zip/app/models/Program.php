<?php
class Program extends Eloquent{

}
