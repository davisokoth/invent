<?php
class Author extends Eloquent {

}