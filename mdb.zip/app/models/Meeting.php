<?php
class Meeting extends Eloquent {

}