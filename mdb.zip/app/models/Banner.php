<?php
class Banner extends Eloquent {

}