<?php
class Comment extends Eloquent{
    public function media()
    {
        return $this->belongsTo('Media');
    }
}
