<?php
class Tag extends Eloquent{
    public function jobs()
    {
        return $this->belongsToMany('Job');
    }
}
