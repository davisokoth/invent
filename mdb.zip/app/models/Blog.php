<?php
class Blog extends Eloquent {
	public function user()
    {
        return $this->belongsTo('User', 'author');
    }
}
